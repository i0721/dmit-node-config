# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: authentication-backend.spec.ts >> Backend mode uses CSRF/session API for login, restore and logout without Mock persistence
- Location: apps\web\e2e\authentication-backend.spec.ts:6:1

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /\/login\?returnTo=/
Received string:  "http://127.0.0.1:4174/settings"
Timeout: 5000ms

Call log:
  - Expect "toHaveURL" with timeout 5000ms
    - locator resolved to <html lang="zh-CN" data-theme="light" data-accent="purple" data-motion-swap="on" data-motion-async="on" data-motion-media="on" data-contrast="system" data-motion-screen="on" data-motion-reveal="on" data-density="standard" data-follow-system="on" data-enhance-focus="off" data-motion-mode="system" data-motion-feedback="on" data-content-width="auto" data-enhance-target="off" data-font-scale="standard" data-system-contrast="standard">…</html>
    12 × unexpected value "http://127.0.0.1:4174/settings"
       - locator resolved to <html lang="zh-CN" data-theme="light" data-accent="purple" data-hydrated="true" data-motion-swap="on" data-motion-async="on" data-motion-media="on" data-contrast="system" data-motion-screen="on" data-motion-reveal="on" data-density="standard" data-follow-system="on" data-enhance-focus="off" data-motion-mode="system" data-motion-feedback="on" data-content-width="auto" data-enhance-target="off" data-font-scale="standard" data-system-contrast="standard">…</html>
    - unexpected value "http://127.0.0.1:4174/settings"

```

```yaml
- alert
- link "跳到主要内容 / Skip to content":
  - /url: "#main-content"
- main:
  - link "C Community Console":
    - /url: /welcome
  - button "切换语言"
  - button "切换主题"
  - region "清晰的界面，专注的工作。":
    - paragraph: Community Console
    - heading "清晰的界面，专注的工作。" [level=2]
    - paragraph: 回到熟悉的工作台，让日常任务、个人偏好和操作反馈井然有序。
    - list:
      - listitem: 统一的工作台与导航
      - listitem: 持续保存的界面偏好
      - listitem: 清晰、及时的状态反馈
  - heading "正在确认你的会话" [level=1]
  - paragraph: 确认完成后继续，不会提前显示受保护的内容。
  - status: 正在加载…
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | import AxeBuilder from '@axe-core/playwright';
  3   | 
  4   | // Controlled proposed API responses validate the real Backend adapter and UI.
  5   | // This is not evidence of integration with an actual authentication server.
  6   | test('Backend mode uses CSRF/session API for login, restore and logout without Mock persistence', async ({
  7   |   page,
  8   |   context,
  9   | }) => {
  10  |   let authenticated = false;
  11  |   const writes: { path: string; csrf: string | undefined; body: string | null }[] = [];
  12  |   await context.route('**/api/auth/**', async (route) => {
  13  |     const request = route.request();
  14  |     const path = new URL(request.url()).pathname;
  15  |     if (path === '/api/auth/csrf') {
  16  |       await route.fulfill({ json: { token: 'contract-csrf' } });
  17  |     } else if (path === '/api/auth/session') {
  18  |       await route.fulfill(
  19  |         authenticated
  20  |           ? {
  21  |               json: {
  22  |                 user: {
  23  |                   id: 'backend-review',
  24  |                   name: 'Backend Review',
  25  |                   email: 'backend@example.test',
  26  |                 },
  27  |                 expiresAt: Date.now() + 60_000,
  28  |               },
  29  |             }
  30  |           : { status: 401 },
  31  |       );
  32  |     } else if (path === '/api/auth/access' && request.method() === 'GET') {
  33  |       await route.fulfill(
  34  |         authenticated
  35  |           ? {
  36  |               json: {
  37  |                 user: {
  38  |                   id: 'backend-review',
  39  |                   name: 'Backend Review',
  40  |                   email: 'backend@example.test',
  41  |                   status: 'active',
  42  |                   roleIds: ['viewer'],
  43  |                   version: 1,
  44  |                   createdAt: '2026-10-12T00:00:00.000Z',
  45  |                   updatedAt: '2026-10-12T00:00:00.000Z',
  46  |                 },
  47  |                 permissions: ['account.update'],
  48  |               },
  49  |             }
  50  |           : { status: 401 },
  51  |       );
  52  |     } else if (
  53  |       request.method() === 'POST' &&
  54  |       (path === '/api/auth/login' || path === '/api/auth/logout')
  55  |     ) {
  56  |       writes.push({ path, csrf: request.headers()['x-csrf-token'], body: request.postData() });
  57  |       authenticated = path !== '/api/auth/logout';
  58  |       await route.fulfill({ status: 204 });
  59  |     } else {
  60  |       throw new Error(`Unexpected authentication request: ${request.method()} ${path}`);
  61  |     }
  62  |   });
  63  |   await page.goto('/settings');
> 64  |   await expect(page).toHaveURL(/\/login\?returnTo=/);
      |                      ^ Error: expect(page).toHaveURL(expected) failed
  65  |   await expect(page.getByText('开发演示模式', { exact: true })).toHaveCount(0);
  66  |   await page.getByRole('textbox', { name: '邮箱', exact: true }).fill('backend@example.test');
  67  |   await page.getByLabel('密码', { exact: true }).fill('BackendDemoPass2026!');
  68  |   await page.getByRole('button', { name: '登录', exact: true }).click();
  69  |   await expect(page).toHaveURL('http://127.0.0.1:4174/settings');
  70  |   await page.reload();
  71  |   await page.getByRole('button', { name: '当前用户', exact: true }).click();
  72  |   await expect(page.getByRole('menu').getByText('Backend Review', { exact: true })).toBeVisible();
  73  |   const otherTab = await context.newPage();
  74  |   await otherTab.goto('http://127.0.0.1:4174/settings');
  75  |   await expect(otherTab.getByRole('button', { name: '当前用户', exact: true })).toBeVisible();
  76  |   await page.getByRole('menuitem', { name: '退出登录', exact: true }).click();
  77  |   await expect(page).toHaveURL('http://127.0.0.1:4174/login');
  78  |   await expect(otherTab).toHaveURL(/\/login\?returnTo=/);
  79  |   await expect(otherTab.getByRole('button', { name: '当前用户', exact: true })).toHaveCount(0);
  80  |   await otherTab.close();
  81  |   expect(writes.map((write) => write.path)).toEqual(['/api/auth/login', '/api/auth/logout']);
  82  |   expect(writes.every((write) => write.csrf === 'contract-csrf')).toBe(true);
  83  |   expect(writes[0]?.body).toBe(
  84  |     JSON.stringify({ email: 'backend@example.test', password: 'BackendDemoPass2026!' }),
  85  |   );
  86  |   expect(await page.evaluate(() => localStorage.getItem('community-go.auth-mock'))).toBeNull();
  87  | });
  88  | 
  89  | test('Backend restore failure stays closed, supports retry and never supplies a demo identity', async ({
  90  |   page,
  91  |   context,
  92  | }) => {
  93  |   let healthy = false;
  94  |   await context.route('**/api/auth/session', async (route) => {
  95  |     if (!healthy) await route.abort('failed');
  96  |     else await route.fulfill({ status: 401 });
  97  |   });
  98  |   await page.goto('/reference-resources');
  99  |   await expect(
  100 |     page.getByText('无法连接认证服务，请检查网络后重试。', { exact: true }),
  101 |   ).toBeVisible();
  102 |   await expect(page.getByRole('button', { name: '当前用户', exact: true })).toHaveCount(0);
  103 |   await expect(page.getByText('开发演示模式', { exact: true })).toHaveCount(0);
  104 |   const axe = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
  105 |   expect(axe.violations).toEqual([]);
  106 |   healthy = true;
  107 |   await page.getByRole('button', { name: '重试', exact: true }).click();
  108 |   await expect(page).toHaveURL(/\/login\?returnTo=/);
  109 |   expect(await page.evaluate(() => localStorage.getItem('community-go.auth-mock'))).toBeNull();
  110 | });
  111 | 
  112 | test('Backend registration reports pending/success and failed logout keeps all private content hidden', async ({
  113 |   page,
  114 |   context,
  115 | }) => {
  116 |   let authenticated = false;
  117 |   let rejectLogout = true;
  118 |   let completeRegistration: (() => void) | undefined;
  119 |   const registration = new Promise<void>((resolve) => {
  120 |     completeRegistration = resolve;
  121 |   });
  122 |   await context.route('**/api/auth/**', async (route) => {
  123 |     const path = new URL(route.request().url()).pathname;
  124 |     if (path === '/api/auth/csrf') await route.fulfill({ json: { token: 'register-csrf' } });
  125 |     else if (path === '/api/auth/registration-policy')
  126 |       await route.fulfill({ json: { enabled: true } });
  127 |     else if (path === '/api/auth/session')
  128 |       await route.fulfill(
  129 |         authenticated
  130 |           ? {
  131 |               json: {
  132 |                 user: { id: 'new-backend', name: 'New Backend', email: 'new-backend@example.test' },
  133 |                 expiresAt: Date.now() + 60_000,
  134 |               },
  135 |             }
  136 |           : { status: 401 },
  137 |       );
  138 |     else if (path === '/api/auth/register') {
  139 |       await registration;
  140 |       authenticated = true;
  141 |       expect(route.request().postData()).toBe(
  142 |         JSON.stringify({
  143 |           email: 'new-backend@example.test',
  144 |           password: 'BackendRegister2026!',
  145 |           name: 'New Backend',
  146 |         }),
  147 |       );
  148 |       await route.fulfill({ status: 204 });
  149 |     } else if (path === '/api/auth/logout') {
  150 |       if (rejectLogout) await route.fulfill({ status: 503 });
  151 |       else {
  152 |         authenticated = false;
  153 |         await route.fulfill({ status: 204 });
  154 |       }
  155 |     } else await route.fulfill({ status: 404 });
  156 |   });
  157 |   await page.goto('/register');
  158 |   await page.getByRole('textbox', { name: '姓名', exact: true }).fill('New Backend');
  159 |   await page.getByRole('textbox', { name: '邮箱', exact: true }).fill('new-backend@example.test');
  160 |   await page.getByLabel('密码', { exact: true }).fill('BackendRegister2026!');
  161 |   await page.getByLabel('确认密码', { exact: true }).fill('BackendRegister2026!');
  162 |   await page.getByRole('button', { name: '创建账户', exact: true }).click();
  163 |   await expect(page.getByRole('textbox', { name: '姓名', exact: true })).toBeDisabled();
  164 |   completeRegistration?.();
```