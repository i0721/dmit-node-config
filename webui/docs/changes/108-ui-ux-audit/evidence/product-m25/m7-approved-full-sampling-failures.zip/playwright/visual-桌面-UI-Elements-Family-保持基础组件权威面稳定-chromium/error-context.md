# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: visual.spec.ts >> 桌面 UI Elements Family 保持基础组件权威面稳定
- Location: apps\web\e2e\visual.spec.ts:28:1

# Error details

```
Error: expect(page).toHaveScreenshot(expected) failed

  23511 pixels (ratio 0.02 of all image pixels) are different.

  Snapshot: ui-elements-desktop.png

Call log:
  - Expect "soft toHaveScreenshot(ui-elements-desktop.png)" with timeout 5000ms
    - verifying given screenshot expectation
  - taking page screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - 24445 pixels (ratio 0.02 of all image pixels) are different.
  - waiting 100ms before taking screenshot
  - taking page screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - captured a stable screenshot
  - 23511 pixels (ratio 0.02 of all image pixels) are different.

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]
  - alert [ref=e11]
  - link "跳到主要内容 / Skip to content" [ref=e12] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e13]:
    - complementary [ref=e14]:
      - generic [ref=e15]:
        - generic [ref=e16]: C
        - generic [ref=e18]:
          - paragraph [ref=e19]: Community Console
          - paragraph [ref=e20]: 管理工作空间
      - navigation "主导航" [ref=e21]:
        - generic [ref=e22]:
          - paragraph [ref=e23]: 工作空间
          - list "工作空间" [ref=e24]:
            - listitem [ref=e25]:
              - link "工作台" [ref=e26] [cursor=pointer]:
                - /url: /
        - generic [ref=e34]:
          - paragraph [ref=e35]: 身份与访问
          - list "身份与访问" [ref=e36]:
            - listitem [ref=e37]:
              - link "用户管理" [ref=e38] [cursor=pointer]:
                - /url: /users
            - listitem [ref=e45]:
              - link "角色管理" [ref=e46] [cursor=pointer]:
                - /url: /roles
            - listitem [ref=e53]:
              - link "审计日志" [ref=e54] [cursor=pointer]:
                - /url: /audit-logs
            - listitem [ref=e60]:
              - link "系统配置" [ref=e61] [cursor=pointer]:
                - /url: /system-settings
        - generic [ref=e67]:
          - paragraph [ref=e68]: 个人
          - list "个人" [ref=e69]:
            - listitem [ref=e70]:
              - link "个人账户" [ref=e71] [cursor=pointer]:
                - /url: /account
            - listitem [ref=e78]:
              - link "通知中心" [ref=e79] [cursor=pointer]:
                - /url: /notifications
            - listitem [ref=e84]:
              - link "个人偏好" [ref=e85] [cursor=pointer]:
                - /url: /settings
        - generic [ref=e91]:
          - paragraph [ref=e92]: 开发中心
          - list "开发中心" [ref=e93]:
            - listitem [ref=e94]:
              - button "展开或收起UI Elements" [expanded] [ref=e95]:
                - generic [ref=e102]: UI Elements
              - list [ref=e105]:
                - listitem [ref=e106]:
                  - link "操作与选择" [ref=e107] [cursor=pointer]:
                    - /url: /ui-elements/actions-selection
                - listitem [ref=e116]:
                  - link "反馈" [ref=e117] [cursor=pointer]:
                    - /url: /ui-elements/feedback
                - listitem [ref=e122]:
                  - link "状态与异步" [ref=e123] [cursor=pointer]:
                    - /url: /ui-elements/status-async
                - listitem [ref=e128]:
                  - link "身份与展示" [ref=e129] [cursor=pointer]:
                    - /url: /ui-elements/identity-display
                - listitem [ref=e136]:
                  - link "导航" [ref=e137] [cursor=pointer]:
                    - /url: /ui-elements/navigation
                - listitem [ref=e147]:
                  - link "数据展示" [ref=e148] [cursor=pointer]:
                    - /url: /ui-elements/data
                - listitem [ref=e153]:
                  - link "表面与卡片" [ref=e154] [cursor=pointer]:
                    - /url: /ui-elements/surfaces
                - listitem [ref=e159]:
                  - link "表单控件" [ref=e160] [cursor=pointer]:
                    - /url: /ui-elements/forms
                - listitem [ref=e166]:
                  - link "浮层与弹出界面" [ref=e167] [cursor=pointer]:
                    - /url: /ui-elements/overlays
            - listitem [ref=e174]:
              - button "展开或收起Page Patterns" [ref=e175]:
                - generic [ref=e182]: Page Patterns
            - listitem [ref=e185]:
              - button "展开或收起Page Archetypes" [ref=e186]:
                - generic [ref=e190]: Page Archetypes
            - listitem [ref=e193]:
              - link "参考资源" [ref=e194] [cursor=pointer]:
                - /url: /reference-resources
            - listitem [ref=e199]:
              - link "Icon 大全" [ref=e200] [cursor=pointer]:
                - /url: /system-tools/icons
            - listitem [ref=e207]:
              - link "基座能力" [ref=e208] [cursor=pointer]:
                - /url: /foundations
            - listitem [ref=e221]:
              - link "Motion" [ref=e222] [cursor=pointer]:
                - /url: /motion
            - listitem [ref=e231]:
              - link "状态体系" [ref=e232] [cursor=pointer]:
                - /url: /states
    - generic [ref=e239]:
      - banner [ref=e241]:
        - button "收起侧栏" [ref=e243] [cursor=pointer]
        - button "按 Ctrl K 搜索" [ref=e245] [cursor=pointer]
        - generic [ref=e246]:
          - generic [ref=e247]:
            - button "切换语言" [ref=e248] [cursor=pointer]
            - button "切换主题" [ref=e249] [cursor=pointer]
          - button "通知" [ref=e250]
          - button "当前用户" [ref=e254] [cursor=pointer]:
            - generic [ref=e256]:
              - generic "Rin" [ref=e259]: RI
              - generic [ref=e260]: Rin
      - main [ref=e264]:
        - generic [ref=e266]:
          - generic [ref=e267]:
            - list "面包屑导航" [ref=e268]:
              - listitem [ref=e269]:
                - link "基座验证" [ref=e270] [cursor=pointer]
                - generic [ref=e271]: /
              - listitem [ref=e272]:
                - link "UI Elements" [ref=e273] [cursor=pointer]
                - generic [ref=e274]: /
              - listitem [ref=e275]:
                - link "操作与选择" [disabled]
            - generic [ref=e277]:
              - paragraph [ref=e278]: UI Elements · Catalog
              - heading "操作与选择" [level=1] [ref=e279]
              - paragraph [ref=e280]: 这是用于验证正常内容节奏的短说明。
          - generic [ref=e281]:
            - generic [ref=e282]:
              - generic [ref=e283]: 展示密度
              - button "舒适 展示密度" [ref=e284] [cursor=pointer]:
                - generic [ref=e285]: 舒适
              - combobox [ref=e292]
            - generic [ref=e294] [cursor=pointer]:
              - switch "扩展文本" [ref=e296]
              - generic [ref=e297]:
                - generic [ref=e298]: 扩展文本
                - generic [ref=e299]: 切换到极长内容以验证传播范围。
            - generic [ref=e303] [cursor=pointer]:
              - switch "English Locale" [ref=e305]
              - generic [ref=e306]:
                - generic [ref=e307]: English Locale
                - generic [ref=e308]: 切换中英文并观察文本扩张与布局。
          - region "UI Elements 分类导航" [ref=e312]:
            - generic [ref=e313]:
              - generic [ref=e314]:
                - paragraph [ref=e315]: 公开契约目录
                - heading "操作与选择" [level=2] [ref=e316]
                - paragraph [ref=e317]: 这是用于验证正常内容节奏的短说明。
              - generic [ref=e318]: 3 / 公开 Element 46 / 46
            - navigation "UI Elements 分类导航" [ref=e320]:
              - link "操作与选择 · 3" [ref=e321] [cursor=pointer]:
                - /url: /ui-elements/actions-selection
              - link "反馈 · 4" [ref=e324] [cursor=pointer]:
                - /url: /ui-elements/feedback
              - link "状态与异步 · 7" [ref=e327] [cursor=pointer]:
                - /url: /ui-elements/status-async
              - link "身份与展示 · 4" [ref=e330] [cursor=pointer]:
                - /url: /ui-elements/identity-display
              - link "导航 · 7" [ref=e333] [cursor=pointer]:
                - /url: /ui-elements/navigation
              - link "数据展示 · 1" [ref=e336] [cursor=pointer]:
                - /url: /ui-elements/data
              - link "表面与卡片 · 2" [ref=e339] [cursor=pointer]:
                - /url: /ui-elements/surfaces
              - link "表单控件 · 10" [ref=e342] [cursor=pointer]:
                - /url: /ui-elements/forms
              - link "浮层与弹出界面 · 8" [ref=e345] [cursor=pointer]:
                - /url: /ui-elements/overlays
          - navigation "本页区段" [ref=e348]:
            - link "Action Variants" [ref=e349] [cursor=pointer]:
              - /url: /ui-elements/actions-selection#actions
            - link "Action" [ref=e350] [cursor=pointer]:
              - /url: /ui-elements/actions-selection#element-action
            - link "IconAction" [ref=e351] [cursor=pointer]:
              - /url: /ui-elements/actions-selection#element-iconaction
            - link "ToggleGroup" [ref=e352] [cursor=pointer]:
              - /url: /ui-elements/actions-selection#element-togglegroup
          - generic [ref=e354]:
            - generic [ref=e356]:
              - heading "Action Variants" [level=2] [ref=e357]
              - paragraph [ref=e358]: 这是用于验证正常内容节奏的短说明。
            - generic [ref=e360]:
              - generic [ref=e361]:
                - generic [ref=e362]:
                  - generic [ref=e363]:
                    - heading "Action" [level=3] [ref=e364]
                    - generic "Action 状态" [ref=e365]:
                      - generic [ref=e366]: 主要
                      - generic [ref=e368]: 次要
                      - generic [ref=e370]: 低强调
                      - generic [ref=e372]: 危险
                      - generic [ref=e374]: sm / md / lg
                      - generic [ref=e376]: 图标
                      - generic [ref=e378]: 提交中
                      - generic [ref=e380]: 禁用
                  - paragraph [ref=e382]: 命令动作以稳定 intent、size、icon 与 pending 语义表达，不承担导航。
                - generic [ref=e384]:
                  - button "主要操作" [ref=e385] [cursor=pointer]
                  - button "次要操作" [ref=e388] [cursor=pointer]
                  - button "低强调操作" [ref=e391] [cursor=pointer]
                  - button "危险操作" [ref=e393] [cursor=pointer]
                  - button "小尺寸" [ref=e395] [cursor=pointer]
                  - button "大尺寸" [ref=e397] [cursor=pointer]
                  - button "处理中" [disabled]
                  - button "不可用" [disabled]
              - generic [ref=e399]:
                - generic [ref=e400]:
                  - generic [ref=e401]:
                    - heading "IconAction" [level=3] [ref=e402]
                    - generic "IconAction 状态" [ref=e403]:
                      - generic [ref=e404]: sm / md
                      - generic [ref=e406]: 活动
                      - generic [ref=e408]: 危险
                      - generic [ref=e410]: 提交中
                      - generic [ref=e412]: 禁用
                      - generic [ref=e414]: 无障碍名称
                  - paragraph [ref=e416]: 空间受限的图标命令必须保留可访问名称、活动态和危险语义。
                - generic [ref=e418]:
                  - button "搜索" [ref=e419] [cursor=pointer]
                  - button "刷新" [ref=e420] [cursor=pointer]
                  - button "删除" [ref=e421] [cursor=pointer]
                  - button "更多操作" [ref=e422] [cursor=pointer]
                  - button "刷新处理中" [disabled]
                  - button "更多操作不可用" [disabled]
              - generic [ref=e423]:
                - generic [ref=e424]:
                  - generic [ref=e425]:
                    - heading "ToggleGroup" [level=3] [ref=e426]
                    - generic "ToggleGroup 状态" [ref=e427]:
                      - generic [ref=e428]: 单选
                      - generic [ref=e430]: 多选
                      - generic [ref=e432]: 选中
                      - generic [ref=e434]: 禁用项目
                      - generic [ref=e436]: sm / md
                      - generic [ref=e438]: 图标
                  - paragraph [ref=e440]: 即时视图偏好支持单选或多选，不与表单 RadioGroup 混用。
                - generic [ref=e442]:
                  - generic [ref=e443]:
                    - generic [ref=e444]: 视图模式
                    - radiogroup "视图模式" [ref=e445]:
                      - radio "网格" [checked] [ref=e446] [cursor=pointer]
                      - radio "列表" [ref=e449] [cursor=pointer]
                      - radio "不可用" [disabled]
                  - generic [ref=e452]:
                    - generic [ref=e453]: 可见列
                    - toolbar "可见列" [ref=e454]:
                      - button "职责层" [pressed] [ref=e455] [cursor=pointer]
                      - button "状态" [pressed] [ref=e457] [cursor=pointer]
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { waitForVisualReadiness } from './visual-readiness';
  3   | 
  4   | async function expectHydrated(page: Page) {
  5   |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  6   |   await waitForVisualReadiness(page);
  7   | }
  8   | 
  9   | async function expectReferenceReady(page: Page) {
  10  |   await expectHydrated(page);
  11  |   await expect(page.getByRole('heading', { level: 1 })).toHaveText('高密度数据工作台');
  12  |   // 默认每页 20 → 首页 20 数据行 + 1 表头。
  13  |   await expect(page.getByRole('grid').getByRole('row')).toHaveCount(21);
  14  | }
  15  | 
  16  | test('桌面与超宽屏 Reference 布局保持稳定', async ({ page }) => {
  17  |   await page.setViewportSize({ width: 1440, height: 900 });
  18  |   await page.goto('/page-archetypes/resource-list');
  19  |   await expectReferenceReady(page);
  20  |   await expect.soft(page).toHaveScreenshot('reference-desktop.png', { fullPage: true });
  21  | 
  22  |   await page.setViewportSize({ width: 1920, height: 1080 });
  23  |   await page.reload();
  24  |   await expectReferenceReady(page);
  25  |   await expect.soft(page).toHaveScreenshot('reference-ultrawide.png', { fullPage: true });
  26  | });
  27  | 
  28  | test('桌面 UI Elements Family 保持基础组件权威面稳定', async ({ page }) => {
  29  |   const consoleErrors: string[] = [];
  30  |   page.on('console', (message) => {
  31  |     if (message.type() === 'error') consoleErrors.push(message.text());
  32  |   });
  33  |   await page.setViewportSize({ width: 1440, height: 1000 });
  34  |   await page.goto('/ui-elements/actions-selection');
  35  |   await expectHydrated(page);
  36  |   await expect(page.getByRole('heading', { level: 1, name: '操作与选择' })).toBeVisible();
  37  |   await expect(page.getByText('公开 Element 46 / 46')).toBeVisible();
> 38  |   await expect.soft(page).toHaveScreenshot('ui-elements-desktop.png', { fullPage: true });
      |                           ^ Error: expect(page).toHaveScreenshot(expected) failed
  39  |   expect(consoleErrors).toEqual([]);
  40  | });
  41  | 
  42  | test('九个 UI Element Family 页面均有独立视觉基线', async ({ page }) => {
  43  |   // Nine independent renders and snapshot comparisons retain their per-assertion limit.
  44  |   test.setTimeout(120_000);
  45  |   await page.setViewportSize({ width: 1440, height: 1000 });
  46  | 
  47  |   const families = [
  48  |     'actions-selection',
  49  |     'feedback',
  50  |     'status-async',
  51  |     'identity-display',
  52  |     'navigation',
  53  |     'data',
  54  |     'surfaces',
  55  |     'forms',
  56  |     'overlays',
  57  |   ] as const;
  58  | 
  59  |   for (const family of families) {
  60  |     await page.goto(`/ui-elements/${family}`);
  61  |     await expectHydrated(page);
  62  |     await expect(page.getByText('公开 Element 46 / 46')).toBeVisible();
  63  |     const sectionId = family === 'actions-selection' ? 'actions' : family;
  64  |     await expect
  65  |       .soft(page.locator(`#${sectionId}`))
  66  |       .toHaveScreenshot(`ui-elements-family-${family}.png`);
  67  |   }
  68  | });
  69  | 
  70  | test('移动窗口、Dark Mode 与英文扩张保持无溢出', async ({ page }) => {
  71  |   await page.setViewportSize({ width: 390, height: 844 });
  72  |   await page.goto('/ui-elements/forms');
  73  |   await expectHydrated(page);
  74  |   await page.getByRole('button', { name: '当前用户', exact: true }).click();
  75  |   await page.getByRole('menuitem', { name: /^主题 / }).click();
  76  |   await page.getByRole('menuitemradio', { name: '深色', exact: true }).click();
  77  |   await page.getByRole('button', { name: '当前用户', exact: true }).click();
  78  |   await page.getByRole('menuitem', { name: '语言 简体中文', exact: true }).click();
  79  |   await page.getByRole('menuitemradio', { name: 'English', exact: true }).click();
  80  |   await expect(page.locator('html')).toHaveAttribute('lang', 'en');
  81  |   const overflow = await page.evaluate(
  82  |     () => document.documentElement.scrollWidth - window.innerWidth,
  83  |   );
  84  |   expect(overflow).toBeLessThanOrEqual(0);
  85  |   await expect.soft(page).toHaveScreenshot('ui-elements-mobile-dark-en.png', { fullPage: true });
  86  | });
  87  | 
  88  | test('移动侧栏打开状态纳入视觉回归', async ({ page }) => {
  89  |   await page.setViewportSize({ width: 390, height: 844 });
  90  |   await page.goto('/page-archetypes/resource-list');
  91  |   await expectHydrated(page);
  92  |   await page.getByRole('button', { name: '打开导航' }).click();
  93  |   await expect(page.getByRole('navigation', { name: '主导航' })).toBeVisible();
  94  |   await expect.soft(page).toHaveScreenshot('mobile-navigation-open.png');
  95  | });
  96  | 
  97  | test('状态体系页面保持 Loading 与异常状态视觉基线', async ({ page }) => {
  98  |   await page.setViewportSize({ width: 1440, height: 900 });
  99  |   await page.goto('/states');
  100 |   await expectHydrated(page);
  101 |   await expect(page.getByRole('heading', { name: '加载未完成' })).toBeVisible();
  102 |   await expect(page.getByRole('region', { name: '正在同步界面能力' })).toHaveAttribute(
  103 |     'aria-busy',
  104 |     'true',
  105 |   );
  106 |   await expect.soft(page).toHaveScreenshot('states-desktop.png', { fullPage: true });
  107 | });
  108 | 
  109 | test('Overview、Reference Form 与 Settings 真实页面进入视觉矩阵', async ({ page }) => {
  110 |   await page.setViewportSize({ width: 1440, height: 900 });
  111 | 
  112 |   await page.goto('/');
  113 |   await expectHydrated(page);
  114 |   await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  115 |   await expect.soft(page).toHaveScreenshot('overview-desktop.png', { fullPage: true });
  116 | 
  117 |   await page.goto('/page-archetypes/create-edit');
  118 |   await expectHydrated(page);
  119 |   await expect(page.getByRole('heading', { name: '复杂设置与审批表单' })).toBeVisible();
  120 |   await expect.soft(page).toHaveScreenshot('reference-form-desktop.png', { fullPage: true });
  121 | 
  122 |   await page.goto('/settings');
  123 |   await expectHydrated(page);
  124 |   // 根 /settings 即默认外观分类页（无索引主页）。
  125 |   await expect(page.getByRole('heading', { level: 1, name: '外观' })).toBeVisible();
  126 |   await expect.soft(page).toHaveScreenshot('settings-desktop.png', { fullPage: true });
  127 | });
  128 | 
  129 | test('Toast、Destructive Confirm 与 Compact Density 开启态进入视觉矩阵', async ({ page }) => {
  130 |   await page.setViewportSize({ width: 1440, height: 900 });
  131 | 
  132 |   await page.goto('/ui-elements/feedback?overlay=toast&density=compact');
  133 |   await expectHydrated(page);
  134 |   await expect(page.getByText('项目反馈已入队')).toBeVisible();
  135 |   await expect.soft(page).toHaveScreenshot('ui-elements-toast-compact.png');
  136 | 
  137 |   await page.goto('/ui-elements/overlays?overlay=confirm');
  138 |   await expectHydrated(page);
```