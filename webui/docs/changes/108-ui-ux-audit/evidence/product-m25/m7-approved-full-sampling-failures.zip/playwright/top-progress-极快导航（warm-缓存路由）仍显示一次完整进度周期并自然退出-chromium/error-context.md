# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: top-progress.spec.ts >> 极快导航（warm 缓存路由）仍显示一次完整进度周期并自然退出
- Location: apps\web\e2e\top-progress.spec.ts:59:1

# Error details

```
Error: expect(received).not.toBeNull()

Received: null

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - button "Open Next.js Dev Tools" [ref=f1e7] [cursor=pointer]
  - alert [ref=f1e11]: Overlay 与 Floating Layer
  - link "跳到主要内容 / Skip to content" [ref=f1e12] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f1e13]:
    - complementary [ref=f1e14]:
      - generic [ref=f1e15]:
        - generic [ref=f1e16]: C
        - generic [ref=f1e18]:
          - paragraph [ref=f1e19]: Community Console
          - paragraph [ref=f1e20]: 管理工作空间
      - navigation "主导航" [ref=f1e21]:
        - generic [ref=f1e22]:
          - paragraph [ref=f1e23]: 工作空间
          - list "工作空间" [ref=f1e24]:
            - listitem [ref=f1e25]:
              - link "工作台" [ref=f1e26] [cursor=pointer]:
                - /url: /
        - generic [ref=f1e34]:
          - paragraph [ref=f1e35]: 身份与访问
          - list "身份与访问" [ref=f1e36]:
            - listitem [ref=f1e37]:
              - link "用户管理" [ref=f1e38] [cursor=pointer]:
                - /url: /users
            - listitem [ref=f1e45]:
              - link "角色管理" [ref=f1e46] [cursor=pointer]:
                - /url: /roles
            - listitem [ref=f1e53]:
              - link "审计日志" [ref=f1e54] [cursor=pointer]:
                - /url: /audit-logs
            - listitem [ref=f1e60]:
              - link "系统配置" [ref=f1e61] [cursor=pointer]:
                - /url: /system-settings
        - generic [ref=f1e67]:
          - paragraph [ref=f1e68]: 个人
          - list "个人" [ref=f1e69]:
            - listitem [ref=f1e70]:
              - link "个人账户" [ref=f1e71] [cursor=pointer]:
                - /url: /account
            - listitem [ref=f1e78]:
              - link "通知中心" [ref=f1e79] [cursor=pointer]:
                - /url: /notifications
            - listitem [ref=f1e84]:
              - link "个人偏好" [ref=f1e85] [cursor=pointer]:
                - /url: /settings
        - generic [ref=f1e91]:
          - paragraph [ref=f1e92]: 开发中心
          - list "开发中心" [ref=f1e93]:
            - listitem [ref=f1e94]:
              - button "展开或收起UI Elements" [expanded] [ref=f1e95]:
                - generic [ref=f1e102]: UI Elements
              - list [ref=f1e105]:
                - listitem [ref=f1e106]:
                  - link "操作与选择" [ref=f1e107] [cursor=pointer]:
                    - /url: /ui-elements/actions-selection
                - listitem [ref=f1e116]:
                  - link "反馈" [ref=f1e117] [cursor=pointer]:
                    - /url: /ui-elements/feedback
                - listitem [ref=f1e122]:
                  - link "状态与异步" [ref=f1e123] [cursor=pointer]:
                    - /url: /ui-elements/status-async
                - listitem [ref=f1e128]:
                  - link "身份与展示" [ref=f1e129] [cursor=pointer]:
                    - /url: /ui-elements/identity-display
                - listitem [ref=f1e136]:
                  - link "导航" [ref=f1e137] [cursor=pointer]:
                    - /url: /ui-elements/navigation
                - listitem [ref=f1e147]:
                  - link "数据展示" [ref=f1e148] [cursor=pointer]:
                    - /url: /ui-elements/data
                - listitem [ref=f1e153]:
                  - link "表面与卡片" [ref=f1e154] [cursor=pointer]:
                    - /url: /ui-elements/surfaces
                - listitem [ref=f1e159]:
                  - link "表单控件" [ref=f1e160] [cursor=pointer]:
                    - /url: /ui-elements/forms
                - listitem [ref=f1e166]:
                  - link "浮层与弹出界面" [active] [ref=f1e167] [cursor=pointer]:
                    - /url: /ui-elements/overlays
            - listitem [ref=f1e174]:
              - button "展开或收起Page Patterns" [ref=f1e175]:
                - generic [ref=f1e182]: Page Patterns
            - listitem [ref=f1e185]:
              - button "展开或收起Page Archetypes" [ref=f1e186]:
                - generic [ref=f1e190]: Page Archetypes
            - listitem [ref=f1e193]:
              - link "参考资源" [ref=f1e194] [cursor=pointer]:
                - /url: /reference-resources
            - listitem [ref=f1e199]:
              - link "Icon 大全" [ref=f1e200] [cursor=pointer]:
                - /url: /system-tools/icons
            - listitem [ref=f1e207]:
              - link "基座能力" [ref=f1e208] [cursor=pointer]:
                - /url: /foundations
            - listitem [ref=f1e221]:
              - link "Motion" [ref=f1e222] [cursor=pointer]:
                - /url: /motion
            - listitem [ref=f1e231]:
              - link "状态体系" [ref=f1e232] [cursor=pointer]:
                - /url: /states
    - generic [ref=f1e239]:
      - banner [ref=f1e241]:
        - button "收起侧栏" [ref=f1e243] [cursor=pointer]
        - button "按 Ctrl K 搜索" [ref=f1e245] [cursor=pointer]
        - generic [ref=f1e246]:
          - generic [ref=f1e247]:
            - button "切换语言" [ref=f1e248] [cursor=pointer]
            - button "切换主题" [ref=f1e249] [cursor=pointer]
          - button "通知" [ref=f1e250]
          - button "当前用户" [ref=f1e254] [cursor=pointer]:
            - generic [ref=f1e256]:
              - generic "Rin" [ref=f1e259]: RI
              - generic [ref=f1e260]: Rin
      - main [ref=f1e264]:
        - generic [ref=f1e266]:
          - generic [ref=f1e267]:
            - list "面包屑导航" [ref=f1e268]:
              - listitem [ref=f1e269]:
                - link "基座验证" [ref=f1e270] [cursor=pointer]
                - generic [ref=f1e271]: /
              - listitem [ref=f1e272]:
                - link "UI Elements" [ref=f1e273] [cursor=pointer]
                - generic [ref=f1e274]: /
              - listitem [ref=f1e275]:
                - link "Overlay 与 Floating Layer" [disabled]
            - generic [ref=f1e277]:
              - paragraph [ref=f1e278]: UI Elements · Catalog
              - heading "Overlay 与 Floating Layer" [level=1] [ref=f1e279]
              - paragraph [ref=f1e280]: 每个 Trigger 与展开层均由 UI Adapter 组合 HeroUI，并纳入视觉回归。
          - generic [ref=f1e281]:
            - generic [ref=f1e282]:
              - generic [ref=f1e283]: 展示密度
              - button "舒适 展示密度" [ref=f1e284] [cursor=pointer]:
                - generic [ref=f1e285]: 舒适
              - combobox [ref=f1e292]
            - generic [ref=f1e294] [cursor=pointer]:
              - switch "扩展文本" [ref=f1e296]
              - generic [ref=f1e297]:
                - generic [ref=f1e298]: 扩展文本
                - generic [ref=f1e299]: 切换到极长内容以验证传播范围。
            - generic [ref=f1e303] [cursor=pointer]:
              - switch "English Locale" [ref=f1e305]
              - generic [ref=f1e306]:
                - generic [ref=f1e307]: English Locale
                - generic [ref=f1e308]: 切换中英文并观察文本扩张与布局。
          - region "UI Elements 分类导航" [ref=f1e312]:
            - generic [ref=f1e313]:
              - generic [ref=f1e314]:
                - paragraph [ref=f1e315]: 公开契约目录
                - heading "Overlay 与 Floating Layer" [level=2] [ref=f1e316]
                - paragraph [ref=f1e317]: 每个 Trigger 与展开层均由 UI Adapter 组合 HeroUI，并纳入视觉回归。
              - generic [ref=f1e318]: 8 / 公开 Element 46 / 46
            - navigation "UI Elements 分类导航" [ref=f1e320]:
              - link "操作与选择 · 3" [ref=f1e321] [cursor=pointer]:
                - /url: /ui-elements/actions-selection
              - link "反馈 · 4" [ref=f1e324] [cursor=pointer]:
                - /url: /ui-elements/feedback
              - link "状态与异步 · 7" [ref=f1e327] [cursor=pointer]:
                - /url: /ui-elements/status-async
              - link "身份与展示 · 4" [ref=f1e330] [cursor=pointer]:
                - /url: /ui-elements/identity-display
              - link "导航 · 7" [ref=f1e333] [cursor=pointer]:
                - /url: /ui-elements/navigation
              - link "数据展示 · 1" [ref=f1e336] [cursor=pointer]:
                - /url: /ui-elements/data
              - link "表面与卡片 · 2" [ref=f1e339] [cursor=pointer]:
                - /url: /ui-elements/surfaces
              - link "表单控件 · 10" [ref=f1e342] [cursor=pointer]:
                - /url: /ui-elements/forms
              - link "浮层与弹出界面 · 8" [ref=f1e345] [cursor=pointer]:
                - /url: /ui-elements/overlays
          - navigation "本页区段" [ref=f1e348]:
            - link "Overlay 与 Floating Layer" [ref=f1e349] [cursor=pointer]:
              - /url: /ui-elements/overlays#overlays
            - link "MenuButton" [ref=f1e350] [cursor=pointer]:
              - /url: /ui-elements/overlays#element-menubutton
            - link "MenuButton · Groups / Submenu" [ref=f1e351] [cursor=pointer]:
              - /url: /ui-elements/overlays#element-menubutton-groups-submenu
            - link "PopoverCard" [ref=f1e352] [cursor=pointer]:
              - /url: /ui-elements/overlays#element-popovercard
            - link "TooltipAction" [ref=f1e353] [cursor=pointer]:
              - /url: /ui-elements/overlays#element-tooltipaction
            - link "DialogSurface" [ref=f1e354] [cursor=pointer]:
              - /url: /ui-elements/overlays#element-dialogsurface
            - link "ConfirmDialog" [ref=f1e355] [cursor=pointer]:
              - /url: /ui-elements/overlays#element-confirmdialog
            - link "DestructiveConfirmDialog" [ref=f1e356] [cursor=pointer]:
              - /url: /ui-elements/overlays#element-destructiveconfirmdialog
            - link "DrawerSurface" [ref=f1e357] [cursor=pointer]:
              - /url: /ui-elements/overlays#element-drawersurface
            - link "CommandMenu" [ref=f1e358] [cursor=pointer]:
              - /url: /ui-elements/overlays#element-commandmenu
          - generic [ref=f1e360]:
            - generic [ref=f1e362]:
              - heading "Overlay 与 Floating Layer" [level=2] [ref=f1e363]
              - paragraph [ref=f1e364]: 每个 Trigger 与展开层均由 UI Adapter 组合 HeroUI，并纳入视觉回归。
            - generic [ref=f1e366]:
              - generic [ref=f1e367]:
                - generic [ref=f1e368]:
                  - generic [ref=f1e369]:
                    - heading "MenuButton" [level=3] [ref=f1e370]
                    - generic "MenuButton 状态" [ref=f1e371]:
                      - generic [ref=f1e372]: 默认
                      - generic [ref=f1e374]: 图标
                      - generic [ref=f1e376]: 说明
                      - generic [ref=f1e378]: 禁用
                      - generic [ref=f1e380]: 危险
                      - generic [ref=f1e382]: 键盘
                  - paragraph [ref=f1e384]: MenuButton 承载命令集合，区分普通、危险和不可用 Item。
                - button "Reference 操作菜单" [ref=f1e386] [cursor=pointer]: Dropdown Menu
              - generic [ref=f1e387]:
                - generic [ref=f1e388]:
                  - generic [ref=f1e389]:
                    - heading "MenuButton · Groups / Submenu" [level=3] [ref=f1e390]
                    - generic "MenuButton · Groups / Submenu 状态" [ref=f1e391]:
                      - generic [ref=f1e392]: 分组
                      - generic [ref=f1e394]: 选中
                      - generic [ref=f1e396]: 二级菜单
                      - generic [ref=f1e398]: 键盘
                      - generic [ref=f1e400]: 触摸
                      - generic [ref=f1e402]: 碰撞避让
                  - paragraph [ref=f1e404]: 分组与二级菜单
                - button "分组与二级菜单" [ref=f1e406] [cursor=pointer]
              - generic [ref=f1e407]:
                - generic [ref=f1e408]:
                  - generic [ref=f1e409]:
                    - heading "PopoverCard" [level=3] [ref=f1e410]
                    - generic "PopoverCard 状态" [ref=f1e411]:
                      - generic [ref=f1e412]: 触发器
                      - generic [ref=f1e414]: 标题
                      - generic [ref=f1e416]: 长内容
                      - generic [ref=f1e418]: 焦点返回
                      - generic [ref=f1e420]: 碰撞避让
                  - paragraph [ref=f1e422]: PopoverCard 承载与 Trigger 相关的可交互短内容，不替代 Tooltip 或 Dialog。
                - button "Popover" [ref=f1e424] [cursor=pointer]
              - generic [ref=f1e425]:
                - generic [ref=f1e426]:
                  - generic [ref=f1e427]:
                    - heading "TooltipAction" [level=3] [ref=f1e428]
                    - generic "TooltipAction 状态" [ref=f1e429]:
                      - generic [ref=f1e430]: 悬停
                      - generic [ref=f1e432]: 焦点
                      - generic [ref=f1e434]: 延迟
                      - generic [ref=f1e436]: Escape 键
                      - generic [ref=f1e438]: 非交互内容
                  - paragraph [ref=f1e440]: Tooltip 只提供简短非交互说明，同时支持 Hover 与 Keyboard Focus。
                - generic [ref=f1e441]:
                  - button "Tooltip" [ref=f1e442]
                  - generic [ref=f1e443]:
                    - link "组合提示" [ref=f1e444] [cursor=pointer]:
                      - /url: "#element-popovercard"
                    - button "Overlay 与 Floating Layer" [ref=f1e448] [cursor=pointer]
              - generic [ref=f1e455]:
                - generic [ref=f1e456]:
                  - generic [ref=f1e457]:
                    - heading "DialogSurface" [level=3] [ref=f1e458]
                    - generic "DialogSurface 状态" [ref=f1e459]:
                      - generic [ref=f1e460]: 表单内容
                      - generic [ref=f1e462]: 取消
                      - generic [ref=f1e464]: 确认
                      - generic [ref=f1e466]: 提交中
                      - generic [ref=f1e468]: 失败
                      - generic [ref=f1e470]: 焦点隔离
                  - paragraph [ref=f1e472]: DialogSurface 承载普通表单决策，并统一焦点、Pending、失败与 Footer。
                - button "Dialog" [ref=f1e474] [cursor=pointer]
              - generic [ref=f1e475]:
                - generic [ref=f1e476]:
                  - generic [ref=f1e477]:
                    - heading "ConfirmDialog" [level=3] [ref=f1e478]
                    - generic "ConfirmDialog 状态" [ref=f1e479]:
                      - generic [ref=f1e480]: 影响范围
                      - generic [ref=f1e482]: 取消
                      - generic [ref=f1e484]: 确认
                      - generic [ref=f1e486]: 禁用
                      - generic [ref=f1e488]: 提交中
                      - generic [ref=f1e490]: 失败
                  - paragraph [ref=f1e492]: ConfirmDialog 用于需要显式确认的普通决策，并呈现影响范围。
                - button "普通确认" [ref=f1e494] [cursor=pointer]
              - generic [ref=f1e495]:
                - generic [ref=f1e496]:
                  - generic [ref=f1e497]:
                    - heading "DestructiveConfirmDialog" [level=3] [ref=f1e498]
                    - generic "DestructiveConfirmDialog 状态" [ref=f1e499]:
                      - generic [ref=f1e500]: 危险语义
                      - generic [ref=f1e502]: 影响范围
                      - generic [ref=f1e504]: 提交中
                      - generic [ref=f1e506]: 失败
                      - generic [ref=f1e508]: 焦点恢复
                  - paragraph [ref=f1e510]: Destructive Confirm 以危险语义强调不可逆后果，不与普通确认共用视觉。
                - button "危险确认" [ref=f1e512] [cursor=pointer]
              - generic [ref=f1e513]:
                - generic [ref=f1e514]:
                  - generic [ref=f1e515]:
                    - heading "DrawerSurface" [level=3] [ref=f1e516]
                    - generic "DrawerSurface 状态" [ref=f1e517]:
                      - generic [ref=f1e518]: 右侧抽屉
                      - generic [ref=f1e520]: 标题与正文
                      - generic [ref=f1e522]: 关闭
                      - generic [ref=f1e524]: 滚动
                      - generic [ref=f1e526]: 窄视口
                  - paragraph [ref=f1e528]: Drawer 在侧边承载辅助任务，拥有独立 Header、Body、关闭和滚动边界。
                - button "Drawer" [ref=f1e530] [cursor=pointer]
              - generic [ref=f1e531]:
                - generic [ref=f1e532]:
                  - generic [ref=f1e533]:
                    - heading "CommandMenu" [level=3] [ref=f1e534]
                    - generic "CommandMenu 状态" [ref=f1e535]:
                      - generic [ref=f1e536]: 搜索
                      - generic [ref=f1e538]: 已筛选
                      - generic [ref=f1e540]: 空状态
                      - generic [ref=f1e542]: 键盘操作
                      - generic [ref=f1e544]: 模态焦点
                  - paragraph [ref=f1e546]: CommandMenu 组合搜索、过滤、空结果和键盘命令执行。
                - button "Command" [ref=f1e548] [cursor=pointer]
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | 
  3   | // 应用级顶部进度条（Top Progress）验证。
  4   | // 进度条是装饰性反馈（aria-hidden=true），通过 DOM 选择器断言，不用角色查询。
  5   | // 生命周期由 Host 导航入口提供：Sidebar Link / CommandMenu / RouterTextLink 等
  6   | // begin；RouteTransition 在 pathname 提交时 end。
  7   | // 视觉验收以"最终浏览器像素结果"为准：viewport 顶部、非零尺寸、opacity≠0、
  8   | // foreground 实际延伸、完成后退出——不是只断言 DOM 存在或 data-state。
  9   | // 最小可见周期：即使极快导航（缓存路由 <60ms 完成）也必须显示一次完整进度周期。
  10  | 
  11  | const progressBar = (page: Page) => page.locator('.top-progress');
  12  | 
  13  | async function expectHydrated(page: Page) {
  14  |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  15  | }
  16  | 
  17  | // 慢速导航：拦截目标路由的 RSC 请求并延迟，使客户端导航持续 Pending，
  18  | // 进度条在 active 阶段持续延伸、不提前达到 100%。
  19  | async function delayRscRoute(page: Page, pathname: string, delayMs: number) {
  20  |   await page.route(`**${pathname}?_rsc*`, async (route) => {
  21  |     await new Promise((resolve) => setTimeout(resolve, delayMs));
  22  |     await route.continue();
  23  |   });
  24  | }
  25  | 
  26  | // 桌面侧边栏：展开"UI Elements"并点击目标叶子。
  27  | async function navigateViaSidebar(page: Page, leafName: string) {
  28  |   const navigation = page.getByRole('navigation', { name: '主导航' });
  29  |   await navigation.getByRole('button', { name: '展开或收起UI Elements' }).click();
  30  |   await navigation.getByRole('link', { name: leafName }).click();
  31  | }
  32  | 
  33  | // 窄屏：先打开移动端导航抽屉，再展开"UI Elements"并点击叶子。
  34  | async function navigateViaMobileNav(page: Page, leafName: string) {
  35  |   await page.getByRole('button', { name: '打开导航' }).click();
  36  |   const navigation = page.getByRole('navigation', { name: '主导航' });
  37  |   await navigation.getByRole('button', { name: '展开或收起UI Elements' }).click();
  38  |   await navigation.getByRole('link', { name: leafName }).click();
  39  | }
  40  | 
  41  | // 读取进度条 fill 的"最终像素可见性"代理：boundingBox + 计算样式。
  42  | async function readFillVisibility(page: Page) {
  43  |   return page.evaluate(() => {
  44  |     const fill = document.querySelector('.top-progress-fill');
  45  |     if (!fill) return null;
  46  |     const rect = fill.getBoundingClientRect();
  47  |     const cs = getComputedStyle(fill);
  48  |     return {
  49  |       left: Math.round(rect.left),
  50  |       top: Math.round(rect.top),
  51  |       width: Math.round(rect.width),
  52  |       height: Math.round(rect.height),
  53  |       opacity: Number(cs.opacity),
  54  |       backgroundColor: cs.backgroundColor,
  55  |     };
  56  |   });
  57  | }
  58  | 
  59  | test('极快导航（warm 缓存路由）仍显示一次完整进度周期并自然退出', async ({ page }) => {
  60  |   await page.setViewportSize({ width: 1440, height: 900 });
  61  |   // warm 目标路由使其走缓存导航
  62  |   await page.goto('/ui-elements/overlays');
  63  |   await expectHydrated(page);
  64  |   await page.goto('/');
  65  |   await expectHydrated(page);
  66  | 
  67  |   await navigateViaSidebar(page, '浮层与弹出界面');
  68  |   await expect(page).toHaveURL(/\/ui-elements\/overlays$/);
  69  |   await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  70  | 
  71  |   // 即使导航极快（缓存路由，<60ms 完成），也保证最小视觉周期：
  72  |   // 进度条必须出现过（enter/completing），且最终自然退出。
  73  |   await expect
  74  |     .poll(async () => {
  75  |       const count = await progressBar(page).count();
  76  |       if (count === 0) return null;
  77  |       const phase = await progressBar(page).getAttribute('data-phase');
  78  |       return { count, phase };
  79  |     })
> 80  |     .not.toBeNull();
      |          ^ Error: expect(received).not.toBeNull()
  81  |   await expect(progressBar(page)).toHaveCount(0);
  82  | });
  83  | 
  84  | test('普通首次导航（未缓存路由）能感知到进度条', async ({ page }) => {
  85  |   await page.setViewportSize({ width: 1440, height: 900 });
  86  |   await page.goto('/');
  87  |   await expectHydrated(page);
  88  | 
  89  |   // 首次导航 /motion（未 warm、未缓存），真实用户典型场景
  90  |   await page
  91  |     .getByRole('navigation', { name: '主导航' })
  92  |     .getByRole('link', { name: 'Motion' })
  93  |     .click();
  94  | 
  95  |   await expect(page).toHaveURL(/\/motion$/);
  96  |   await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  97  |   await expect(progressBar(page)).toHaveCount(0);
  98  | });
  99  | 
  100 | test('慢速导航：进度条在 viewport 顶部、非零可见尺寸、foreground 实际延伸、完成后退出', async ({
  101 |   page,
  102 | }) => {
  103 |   await page.setViewportSize({ width: 1440, height: 900 });
  104 |   await page.goto('/');
  105 |   await expectHydrated(page);
  106 | 
  107 |   // 拦截 RSC 请求延迟 1800ms，制造慢速导航
  108 |   await delayRscRoute(page, '/ui-elements/feedback', 1800);
  109 | 
  110 |   await navigateViaSidebar(page, '反馈');
  111 | 
  112 |   // 导航进行中：进度条出现且 pending
  113 |   await expect(progressBar(page)).toHaveCount(1);
  114 |   await expect(progressBar(page)).toHaveAttribute('data-phase', 'pending');
  115 | 
  116 |   // 采样 fill 宽度序列，验证"只前进不回缩"：进度条绝不加载到一半又从零开始。
  117 |   await page.evaluate(() => {
  118 |     const widths: number[] = [];
  119 |     (window as unknown as { __progressWidths?: number[] }).__progressWidths = widths;
  120 |     const startedAt = performance.now();
  121 |     const poll = () => {
  122 |       const fill = document.querySelector('.top-progress-fill');
  123 |       if (fill) {
  124 |         widths.push(Math.round(fill.getBoundingClientRect().width));
  125 |       }
  126 |       if (performance.now() - startedAt < 1200) requestAnimationFrame(poll);
  127 |     };
  128 |     requestAnimationFrame(poll);
  129 |   });
  130 | 
  131 |   // 像素级验证：fill 在 viewport 顶部、非零尺寸、opacity 不为 0、色值为 brand 语义色
  132 |   await expect
  133 |     .poll(async () => {
  134 |       const v = await readFillVisibility(page);
  135 |       if (!v) return null;
  136 |       const visible =
  137 |         v.width > 0 &&
  138 |         v.height > 0 &&
  139 |         v.opacity > 0.05 &&
  140 |         v.left >= 0 &&
  141 |         v.left < 1440 &&
  142 |         v.top === 0;
  143 |       return visible ? { width: v.width, height: v.height, opacity: v.opacity } : null;
  144 |     })
  145 |     .not.toBeNull();
  146 | 
  147 |   const during = await readFillVisibility(page);
  148 |   expect(during).not.toBeNull();
  149 |   expect(during!.width).toBeGreaterThan(0);
  150 |   expect(during!.height).toBe(3);
  151 |   expect(during!.opacity).toBeGreaterThan(0.05);
  152 |   expect(during!.left).toBeGreaterThanOrEqual(0);
  153 |   expect(during!.left).toBeLessThan(1440);
  154 |   expect(during!.backgroundColor).toBe('rgb(93, 73, 214)'); // --ds-brand light
  155 | 
  156 |   // 只前进不回缩：采样到的 fill 宽度序列必须单调不减（允许动画帧内的四舍五入抖动）。
  157 |   const widths = await page.evaluate<number[]>(
  158 |     () => (window as unknown as { __progressWidths?: number[] }).__progressWidths ?? [],
  159 |   );
  160 |   const effectiveWidths = widths.filter(
  161 |     (w: number, index: number) => index === 0 || w !== widths[index - 1],
  162 |   );
  163 |   for (let i = 1; i < effectiveWidths.length; i++) {
  164 |     const current = effectiveWidths[i];
  165 |     const previous = effectiveWidths[i - 1];
  166 |     if (current === undefined || previous === undefined) continue;
  167 |     // 允许 2px 抖动容差（rAF 采样与宽度插值的边界）
  168 |     expect(current).toBeGreaterThanOrEqual(previous - 2);
  169 |   }
  170 | 
  171 |   // 完成后进度条消失
  172 |   await expect(page).toHaveURL(/\/ui-elements\/feedback$/);
  173 |   await expect(progressBar(page)).toHaveCount(0);
  174 | });
  175 | 
  176 | test('连续快速点击不同路由不错误结束、不永久卡住', async ({ page }) => {
  177 |   await page.setViewportSize({ width: 1440, height: 900 });
  178 |   await page.goto('/');
  179 |   await expectHydrated(page);
  180 | 
```