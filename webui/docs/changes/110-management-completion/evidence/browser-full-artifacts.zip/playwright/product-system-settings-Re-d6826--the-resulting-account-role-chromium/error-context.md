# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: product-system-settings.spec.ts >> Registration policy controls public signup and the resulting account role
- Location: apps\web\e2e\product-system-settings.spec.ts:6:1

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: locator.click: Test timeout of 120000ms exceeded.
Call log:
  - waiting for getByRole('option', { name: 'Operator', exact: true })

```

# Page snapshot

```yaml
- generic [ref=f5e1]:
  - button "Open Next.js Dev Tools" [ref=f5e7] [cursor=pointer]
  - alert [ref=f5e11]
  - link "跳到主要内容 / Skip to content" [ref=f5e12] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f5e13]:
    - complementary [ref=f5e14]:
      - generic [ref=f5e15]:
        - generic [ref=f5e16]: C
        - generic [ref=f5e18]:
          - paragraph [ref=f5e19]: Community Console
          - paragraph [ref=f5e20]: 管理工作空间
      - navigation "主导航" [ref=f5e21]:
        - generic [ref=f5e22]:
          - paragraph [ref=f5e23]: 工作空间
          - list "工作空间" [ref=f5e24]:
            - listitem [ref=f5e25]:
              - link "工作台" [ref=f5e26] [cursor=pointer]:
                - /url: /
        - generic [ref=f5e34]:
          - paragraph [ref=f5e35]: 身份与访问
          - list "身份与访问" [ref=f5e36]:
            - listitem [ref=f5e37]:
              - link "用户管理" [ref=f5e38] [cursor=pointer]:
                - /url: /users
            - listitem [ref=f5e45]:
              - link "角色管理" [ref=f5e46] [cursor=pointer]:
                - /url: /roles
        - generic [ref=f5e53]:
          - paragraph [ref=f5e54]: 系统管理
          - list "系统管理" [ref=f5e55]:
            - listitem [ref=f5e56]:
              - link "审计日志" [ref=f5e57] [cursor=pointer]:
                - /url: /audit-logs
            - listitem [ref=f5e63]:
              - link "系统配置" [ref=f5e64] [cursor=pointer]:
                - /url: /system-settings
        - generic [ref=f5e70]:
          - paragraph [ref=f5e71]: 个人
          - list "个人" [ref=f5e72]:
            - listitem [ref=f5e73]:
              - link "个人账户" [ref=f5e74] [cursor=pointer]:
                - /url: /account
            - listitem [ref=f5e81]:
              - link "通知中心" [ref=f5e82] [cursor=pointer]:
                - /url: /notifications
            - listitem [ref=f5e87]:
              - link "个人偏好" [ref=f5e88] [cursor=pointer]:
                - /url: /settings
        - generic [ref=f5e94]:
          - paragraph [ref=f5e95]: 开发中心
          - list "开发中心" [ref=f5e96]:
            - listitem [ref=f5e97]:
              - button "展开或收起UI Elements" [ref=f5e98]:
                - generic [ref=f5e105]: UI Elements
            - listitem [ref=f5e108]:
              - button "展开或收起Page Patterns" [ref=f5e109]:
                - generic [ref=f5e116]: Page Patterns
            - listitem [ref=f5e119]:
              - button "展开或收起Page Archetypes" [ref=f5e120]:
                - generic [ref=f5e124]: Page Archetypes
            - listitem [ref=f5e127]:
              - link "参考资源" [ref=f5e128] [cursor=pointer]:
                - /url: /reference-resources
            - listitem [ref=f5e133]:
              - link "Icon 大全" [ref=f5e134] [cursor=pointer]:
                - /url: /system-tools/icons
            - listitem [ref=f5e141]:
              - link "基座能力" [ref=f5e142] [cursor=pointer]:
                - /url: /foundations
            - listitem [ref=f5e155]:
              - link "Motion" [ref=f5e156] [cursor=pointer]:
                - /url: /motion
            - listitem [ref=f5e165]:
              - link "状态体系" [ref=f5e166] [cursor=pointer]:
                - /url: /states
    - generic [ref=f5e173]:
      - banner [ref=f5e175]:
        - button "收起侧栏" [ref=f5e177] [cursor=pointer]
        - button "按 Ctrl K 搜索" [ref=f5e179] [cursor=pointer]
        - generic [ref=f5e180]:
          - generic [ref=f5e181]:
            - button "切换语言" [ref=f5e182] [cursor=pointer]
            - button "切换主题" [ref=f5e183] [cursor=pointer]
          - button "通知，1 条未读" [ref=f5e184]:
            - generic: "1"
          - button "当前用户" [ref=f5e188] [cursor=pointer]:
            - generic [ref=f5e190]:
              - generic "Rin" [ref=f5e193]: RI
              - generic [ref=f5e194]: Rin
      - main [ref=f5e198]:
        - generic [ref=f5e200]:
          - generic [ref=f5e203]:
            - heading "注册策略" [level=1] [ref=f5e204]
            - paragraph [ref=f5e205]: 管理新账号的注册入口与默认角色；已有账号保持原有授权。
          - paragraph [ref=f5e206]: 演示模式：数据保存在当前浏览器，可刷新恢复；不代表真实后端授权。
          - generic [ref=f5e207]:
            - generic [ref=f5e209]:
              - heading "注册策略" [level=2] [ref=f5e210]
              - paragraph [ref=f5e211]: 管理新账号的注册入口与默认角色；已有账号保持原有授权。
            - generic [ref=f5e213]:
              - generic [ref=f5e214]:
                - generic [ref=f5e215]:
                  - term [ref=f5e216]: 已保存状态
                  - definition [ref=f5e217]: 关闭注册
                - generic [ref=f5e218]:
                  - term [ref=f5e219]: 最后更新时间
                  - definition [ref=f5e220]: 2026/10/13 · 15:22
              - generic [ref=f5e222] [cursor=pointer]:
                - switch "开放公开注册" [checked] [ref=f5e224]
                - generic [ref=f5e225]:
                  - generic [ref=f5e226]: 开放公开注册
                  - generic [ref=f5e227]: 关闭后拒绝新的公开注册，已有账号仍可登录。
              - generic [ref=f5e230]:
                - generic [ref=f5e231]:
                  - generic [ref=f5e232]: 注册账号默认角色
                  - button "受限成员 注册账号默认角色" [expanded] [ref=f5e233] [cursor=pointer]:
                    - generic [ref=f5e234]: 受限成员
                  - generic [ref=f5e239]: 仅可选择不含授权管理或系统写权限的角色，实际角色在提交注册时分配。
                  - combobox [ref=f5e242]
                - generic [ref=f5e243]:
                  - paragraph [ref=f5e244]: 所选角色的权限
                  - list [ref=f5e245]:
                    - listitem [ref=f5e246]: 编辑自己的资料
              - generic [ref=f5e247]:
                - button "恢复已保存值" [ref=f5e248] [cursor=pointer]
                - button "保存策略" [ref=f5e250] [cursor=pointer]
  - dialog [ref=f5e254]:
    - button "取消" [ref=f5e256]
    - listbox "注册账号默认角色" [ref=f5e257]:
      - option "管理员" [disabled]
      - option "操作员" [ref=f5e258]
      - option "受限成员" [active] [selected] [ref=f5e263]
    - button "取消" [ref=f5e269]
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test';
  2   | import AxeBuilder from '@axe-core/playwright';
  3   | import { saveEvidenceScreenshot } from './evidence-screenshot';
  4   | import { waitForVisualReadiness } from './visual-readiness';
  5   | 
  6   | test('Registration policy controls public signup and the resulting account role', async ({
  7   |   page,
  8   | }) => {
  9   |   test.setTimeout(120_000);
  10  |   async function savePolicy() {
  11  |     await page.getByRole('button', { name: '保存策略', exact: true }).click();
  12  |     await page
  13  |       .getByRole('alertdialog', { name: '确认注册策略变更', exact: true })
  14  |       .getByRole('button', { name: '保存策略', exact: true })
  15  |       .click();
  16  |     await expect(page.getByText('注册策略已保存', { exact: true })).toBeVisible();
  17  |   }
  18  |   async function logout() {
  19  |     await page.getByRole('button', { name: '当前用户', exact: true }).click();
  20  |     await page.getByRole('menuitem', { name: '退出登录', exact: true }).click();
  21  |     await expect(page).toHaveURL(/\/login$/);
  22  |   }
  23  |   await page.goto('/system-settings');
  24  |   const registrationSwitch = page.getByRole('switch', { name: '开放公开注册', exact: true });
  25  |   await expect(registrationSwitch).toBeChecked();
  26  |   expect(
  27  |     (
  28  |       await new AxeBuilder({ page })
  29  |         .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
  30  |         .analyze()
  31  |     ).violations,
  32  |   ).toEqual([]);
  33  |   await registrationSwitch.press('Space');
  34  |   await savePolicy();
  35  |   await page.reload();
  36  |   await expect(registrationSwitch).not.toBeChecked();
  37  |   await logout();
  38  |   await page.goto('/register');
  39  |   await expect(
  40  |     page.getByText('公开注册已关闭。如需账户，请联系系统管理员。', { exact: true }),
  41  |   ).toBeVisible();
  42  |   await expect(page.getByRole('textbox', { name: '姓名', exact: true })).toHaveCount(0);
  43  |   await page.getByRole('link', { name: '前往登录', exact: true }).click();
  44  |   await page.getByRole('textbox', { name: '邮箱', exact: true }).fill('demo@community.test');
  45  |   await page.getByLabel('密码', { exact: true }).fill('CommunityDemo2026!');
  46  |   await page.getByRole('button', { name: '登录', exact: true }).click();
  47  |   await expect(page).toHaveURL(/\/$/);
  48  |   await page.goto('/system-settings');
  49  |   await page.getByText('开放公开注册', { exact: true }).click();
  50  |   await page.getByRole('button', { name: /注册账号默认角色/ }).click();
> 51  |   await page.getByRole('option', { name: 'Operator', exact: true }).click();
      |                                                                     ^ Error: locator.click: Test timeout of 120000ms exceeded.
  52  |   await savePolicy();
  53  |   await logout();
  54  |   await page.goto('/register');
  55  |   await page.getByRole('textbox', { name: '姓名', exact: true }).fill('Policy signup');
  56  |   await page.getByRole('textbox', { name: '邮箱', exact: true }).fill('signup-policy@example.test');
  57  |   await page.getByLabel('密码', { exact: true }).fill('PolicySignup2026!');
  58  |   await page.getByLabel('确认密码', { exact: true }).fill('PolicySignup2026!');
  59  |   await page.getByRole('button', { name: '创建账户', exact: true }).click();
  60  |   await expect(page.getByText('账户已创建', { exact: true })).toBeVisible();
  61  |   await page.getByRole('button', { name: '继续进入工作台', exact: true }).click();
  62  |   await expect(
  63  |     page
  64  |       .getByRole('navigation', { name: '主导航' })
  65  |       .getByRole('link', { name: '用户管理', exact: true }),
  66  |   ).toBeVisible();
  67  |   await page.goto('/system-settings');
  68  |   await expect(page.getByRole('heading', { name: '没有操作权限', exact: true })).toBeVisible();
  69  | });
  70  | 
  71  | test('System policy retains keyboard, overlay and accessible layout across sizes and locales', async ({
  72  |   page,
  73  | }, testInfo) => {
  74  |   test.setTimeout(180_000);
  75  |   const errors: string[] = [];
  76  |   page.on('pageerror', (error) => errors.push(error.message));
  77  |   for (const english of [false, true]) {
  78  |     if (english) {
  79  |       await page.goto('/settings/locale');
  80  |       await page.getByRole('radio', { name: 'English', exact: true }).press('Space');
  81  |       await page.goto('/settings');
  82  |       await page.getByRole('radio', { name: 'Dark theme', exact: true }).press('Space');
  83  |     }
  84  |     for (const width of [320, 768, 1440, 2048]) {
  85  |       await page.setViewportSize({ width, height: 900 });
  86  |       await page.goto('/system-settings');
  87  |       const enabled = page.getByRole('switch', {
  88  |         name: english ? 'Allow public registration' : '开放公开注册',
  89  |         exact: true,
  90  |       });
  91  |       await expect(enabled).toBeChecked();
  92  |       expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(
  93  |         width,
  94  |       );
  95  |       await waitForVisualReadiness(page);
  96  |       expect(
  97  |         (
  98  |           await new AxeBuilder({ page })
  99  |             .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
  100 |             .analyze()
  101 |         ).violations,
  102 |       ).toEqual([]);
  103 |       const roleTrigger = page.getByRole('button', {
  104 |         name: english ? /Default role for registered accounts/ : /注册账号默认角色/,
  105 |       });
  106 |       await roleTrigger.click();
  107 |       await expect(
  108 |         page.getByRole('option', { name: english ? 'Administrator' : '管理员', exact: true }),
  109 |       ).toHaveAttribute('aria-disabled', 'true');
  110 |       await waitForVisualReadiness(page);
  111 |       expect(
  112 |         (
  113 |           await new AxeBuilder({ page })
  114 |             .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
  115 |             .analyze()
  116 |         ).violations,
  117 |       ).toEqual([]);
  118 |       await page.keyboard.press('Escape');
  119 |       await expect(roleTrigger).toBeFocused();
  120 |       await enabled.press('Space');
  121 |       const saveLabel = english ? 'Save policy' : '保存策略';
  122 |       await page.getByRole('button', { name: saveLabel, exact: true }).click();
  123 |       const confirmation = page.getByRole('alertdialog', {
  124 |         name: english ? 'Confirm registration policy changes' : '确认注册策略变更',
  125 |         exact: true,
  126 |       });
  127 |       await expect(confirmation).toBeVisible();
  128 |       await waitForVisualReadiness(page);
  129 |       expect(
  130 |         (
  131 |           await new AxeBuilder({ page })
  132 |             .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
  133 |             .analyze()
  134 |         ).violations,
  135 |       ).toEqual([]);
  136 |       await saveEvidenceScreenshot(page, {
  137 |         path: testInfo.outputPath(
  138 |           `system-policy-${english ? 'en-dark' : 'zh-light'}-${width}-confirm.png`,
  139 |         ),
  140 |       });
  141 |       await confirmation
  142 |         .getByRole('button', { name: english ? 'Cancel' : '取消', exact: true })
  143 |         .click();
  144 |       await expect(enabled).not.toBeChecked();
  145 |       await page
  146 |         .getByRole('button', {
  147 |           name: english ? 'Restore saved values' : '恢复已保存值',
  148 |           exact: true,
  149 |         })
  150 |         .click();
  151 |       await expect(enabled).toBeChecked();
```