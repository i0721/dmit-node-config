# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: new-page-open-mode.spec.ts >> 新页面打开方式默认当前页：点击链接同页导航
- Location: apps\web\e2e\new-page-open-mode.spec.ts:11:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('link', { name: '图标工具' })

```

# Page snapshot

```yaml
- generic [active] [ref=f2e1]:
  - button "Open Next.js Dev Tools" [ref=f2e7] [cursor=pointer]
  - alert [ref=f2e11]
  - link "跳到主要内容 / Skip to content" [ref=f2e12] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f2e13]:
    - complementary [ref=f2e14]:
      - generic [ref=f2e15]:
        - generic [ref=f2e16]: C
        - generic [ref=f2e18]:
          - paragraph [ref=f2e19]: Community Console
          - paragraph [ref=f2e20]: 管理工作空间
      - navigation "主导航" [ref=f2e21]:
        - generic [ref=f2e22]:
          - paragraph [ref=f2e23]: 工作空间
          - list "工作空间" [ref=f2e24]:
            - listitem [ref=f2e25]:
              - link "工作台" [ref=f2e26] [cursor=pointer]:
                - /url: /
        - generic [ref=f2e34]:
          - paragraph [ref=f2e35]: 身份与访问
          - list "身份与访问" [ref=f2e36]:
            - listitem [ref=f2e37]:
              - link "用户管理" [ref=f2e38] [cursor=pointer]:
                - /url: /users
            - listitem [ref=f2e45]:
              - link "角色管理" [ref=f2e46] [cursor=pointer]:
                - /url: /roles
        - generic [ref=f2e53]:
          - paragraph [ref=f2e54]: 系统管理
          - list "系统管理" [ref=f2e55]:
            - listitem [ref=f2e56]:
              - link "审计日志" [ref=f2e57] [cursor=pointer]:
                - /url: /audit-logs
            - listitem [ref=f2e63]:
              - link "系统配置" [ref=f2e64] [cursor=pointer]:
                - /url: /system-settings
        - generic [ref=f2e70]:
          - paragraph [ref=f2e71]: 个人
          - list "个人" [ref=f2e72]:
            - listitem [ref=f2e73]:
              - link "个人账户" [ref=f2e74] [cursor=pointer]:
                - /url: /account
            - listitem [ref=f2e81]:
              - link "通知中心" [ref=f2e82] [cursor=pointer]:
                - /url: /notifications
            - listitem [ref=f2e87]:
              - link "个人偏好" [ref=f2e88] [cursor=pointer]:
                - /url: /settings
        - generic [ref=f2e94]:
          - paragraph [ref=f2e95]: 开发中心
          - list "开发中心" [ref=f2e96]:
            - listitem [ref=f2e97]:
              - button "展开或收起UI Elements" [ref=f2e98]:
                - generic [ref=f2e105]: UI Elements
            - listitem [ref=f2e108]:
              - button "展开或收起Page Patterns" [ref=f2e109]:
                - generic [ref=f2e116]: Page Patterns
            - listitem [ref=f2e119]:
              - button "展开或收起Page Archetypes" [ref=f2e120]:
                - generic [ref=f2e124]: Page Archetypes
            - listitem [ref=f2e127]:
              - link "参考资源" [ref=f2e128] [cursor=pointer]:
                - /url: /reference-resources
            - listitem [ref=f2e133]:
              - link "Icon 大全" [ref=f2e134] [cursor=pointer]:
                - /url: /system-tools/icons
            - listitem [ref=f2e141]:
              - link "基座能力" [ref=f2e142] [cursor=pointer]:
                - /url: /foundations
            - listitem [ref=f2e155]:
              - link "Motion" [ref=f2e156] [cursor=pointer]:
                - /url: /motion
            - listitem [ref=f2e165]:
              - link "状态体系" [ref=f2e166] [cursor=pointer]:
                - /url: /states
    - generic [ref=f2e173]:
      - banner [ref=f2e175]:
        - button "收起侧栏" [ref=f2e177] [cursor=pointer]
        - button "按 Ctrl K 搜索" [ref=f2e179] [cursor=pointer]
        - generic [ref=f2e180]:
          - generic [ref=f2e181]:
            - button "切换语言" [ref=f2e182] [cursor=pointer]
            - button "切换主题" [ref=f2e183] [cursor=pointer]
          - button "通知" [ref=f2e184]
          - button "当前用户" [ref=f2e188] [cursor=pointer]:
            - generic [ref=f2e190]:
              - generic "Rin" [ref=f2e193]: RI
              - generic [ref=f2e194]: Rin
      - main [ref=f2e198]:
        - generic [ref=f2e200]:
          - generic [ref=f2e203]:
            - heading "工作台" [level=1] [ref=f2e204]
            - paragraph
          - generic [ref=f2e206]:
            - heading "最近访问" [level=2] [ref=f2e209]
            - paragraph [ref=f2e211]: 访问页面后，最近记录会显示在这里。
```

# Test source

```ts
  1  | import type { Page } from '@playwright/test';
  2  | import { expect, test } from '@playwright/test';
  3  | 
  4  | async function resetPreferences(page: Page) {
  5  |   await page.goto('/settings/navigation');
  6  |   await page.evaluate(() => window.localStorage.removeItem('community-go.shell'));
  7  |   await page.reload();
  8  |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  9  | }
  10 | 
  11 | test('新页面打开方式默认当前页：点击链接同页导航', async ({ page }) => {
  12 |   await resetPreferences(page);
  13 |   await page.goto('/');
  14 |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
> 15 |   await page.getByRole('link', { name: '图标工具' }).click();
     |                                                  ^ Error: locator.click: Test timeout of 30000ms exceeded.
  16 |   await expect(page).toHaveURL(/\/system-tools\/icons/);
  17 | });
  18 | 
  19 | test('新页面打开方式=浏览器新标签页：声明允许入口在新标签打开', async ({ page }) => {
  20 |   await resetPreferences(page);
  21 |   // 设置 → 导航 → 新页面打开方式 = 浏览器新标签页。
  22 |   await page.goto('/settings/navigation');
  23 |   await page.getByRole('heading', { name: '导航' }).first().scrollIntoViewIfNeeded();
  24 |   await page
  25 |     .getByRole('radiogroup', { name: '新页面打开方式' })
  26 |     .getByText('浏览器新标签页', { exact: true })
  27 |     .click();
  28 |   await page.waitForTimeout(300);
  29 | 
  30 |   await page.goto('/');
  31 |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  32 |   const popupPromise = page.waitForEvent('popup');
  33 |   await page.getByRole('link', { name: '图标工具' }).click();
  34 |   const popup = await popupPromise;
  35 |   await popup.waitForLoadState();
  36 |   expect(popup.url()).toContain('/system-tools/icons');
  37 |   // 当前页仍在首页（未被导航离开）。
  38 |   await expect(page).toHaveURL(/\/$/);
  39 | });
  40 | 
```