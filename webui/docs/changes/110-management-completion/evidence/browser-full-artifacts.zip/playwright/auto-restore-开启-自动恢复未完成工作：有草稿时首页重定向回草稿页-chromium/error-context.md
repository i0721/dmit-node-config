# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auto-restore.spec.ts >> 开启 自动恢复未完成工作：有草稿时首页重定向回草稿页
- Location: apps\web\e2e\auto-restore.spec.ts:48:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.focus: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('switch', { name: '自动恢复未完成工作' })

```

# Page snapshot

```yaml
- generic [active] [ref=f2e1]:
  - button "Open Next.js Dev Tools" [ref=f2e7] [cursor=pointer]
  - alert [ref=f2e11]
  - link "跳到主要内容 / Skip to content" [ref=f2e12] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f2e13]:
    - complementary [ref=f2e14]:
      - generic [ref=f2e15]:
        - generic [ref=f2e16]: C
        - generic [ref=f2e18]:
          - paragraph [ref=f2e19]: Community Console
          - paragraph [ref=f2e20]: 管理工作空间
      - navigation "主导航" [ref=f2e21]:
        - generic [ref=f2e22]:
          - paragraph [ref=f2e23]: 工作空间
          - list "工作空间" [ref=f2e24]:
            - listitem [ref=f2e25]:
              - link "工作台" [ref=f2e26] [cursor=pointer]:
                - /url: /
        - generic [ref=f2e34]:
          - paragraph [ref=f2e35]: 身份与访问
          - list "身份与访问" [ref=f2e36]:
            - listitem [ref=f2e37]:
              - link "用户管理" [ref=f2e38] [cursor=pointer]:
                - /url: /users
            - listitem [ref=f2e45]:
              - link "角色管理" [ref=f2e46] [cursor=pointer]:
                - /url: /roles
        - generic [ref=f2e53]:
          - paragraph [ref=f2e54]: 系统管理
          - list "系统管理" [ref=f2e55]:
            - listitem [ref=f2e56]:
              - link "审计日志" [ref=f2e57] [cursor=pointer]:
                - /url: /audit-logs
            - listitem [ref=f2e63]:
              - link "系统配置" [ref=f2e64] [cursor=pointer]:
                - /url: /system-settings
        - generic [ref=f2e70]:
          - paragraph [ref=f2e71]: 个人
          - list "个人" [ref=f2e72]:
            - listitem [ref=f2e73]:
              - link "个人账户" [ref=f2e74] [cursor=pointer]:
                - /url: /account
            - listitem [ref=f2e81]:
              - link "通知中心" [ref=f2e82] [cursor=pointer]:
                - /url: /notifications
            - listitem [ref=f2e87]:
              - link "个人偏好" [ref=f2e88] [cursor=pointer]:
                - /url: /settings
        - generic [ref=f2e94]:
          - paragraph [ref=f2e95]: 开发中心
          - list "开发中心" [ref=f2e96]:
            - listitem [ref=f2e97]:
              - button "展开或收起UI Elements" [ref=f2e98]:
                - generic [ref=f2e105]: UI Elements
            - listitem [ref=f2e108]:
              - button "展开或收起Page Patterns" [ref=f2e109]:
                - generic [ref=f2e116]: Page Patterns
            - listitem [ref=f2e119]:
              - button "展开或收起Page Archetypes" [ref=f2e120]:
                - generic [ref=f2e124]: Page Archetypes
            - listitem [ref=f2e127]:
              - link "参考资源" [ref=f2e128] [cursor=pointer]:
                - /url: /reference-resources
            - listitem [ref=f2e133]:
              - link "Icon 大全" [ref=f2e134] [cursor=pointer]:
                - /url: /system-tools/icons
            - listitem [ref=f2e141]:
              - link "基座能力" [ref=f2e142] [cursor=pointer]:
                - /url: /foundations
            - listitem [ref=f2e155]:
              - link "Motion" [ref=f2e156] [cursor=pointer]:
                - /url: /motion
            - listitem [ref=f2e165]:
              - link "状态体系" [ref=f2e166] [cursor=pointer]:
                - /url: /states
    - generic [ref=f2e173]:
      - banner [ref=f2e175]:
        - button "收起侧栏" [ref=f2e177] [cursor=pointer]
        - button "按 Ctrl K 搜索" [ref=f2e179] [cursor=pointer]
        - generic [ref=f2e180]:
          - generic [ref=f2e181]:
            - button "切换语言" [ref=f2e182] [cursor=pointer]
            - button "切换主题" [ref=f2e183] [cursor=pointer]
          - button "通知" [ref=f2e184]
          - button "当前用户" [ref=f2e188] [cursor=pointer]:
            - generic [ref=f2e190]:
              - generic "Rin" [ref=f2e193]: RI
              - generic [ref=f2e194]: Rin
      - main [ref=f2e198]:
        - generic [ref=f2e200]:
          - generic [ref=f2e203]:
            - paragraph [ref=f2e204]: 个人偏好
            - heading "导航" [level=1] [ref=f2e205]
            - paragraph [ref=f2e206]: 页面访问、侧栏、滚动、面包屑与页面标签。 更改立即生效并保存在当前浏览器。
          - generic [ref=f2e207]:
            - complementary [ref=f2e208]:
              - generic [ref=f2e210]:
                - group [ref=f2e213]:
                  - searchbox "搜索设置项" [ref=f2e214]
                  - button "Close"
                - navigation "设置分类" [ref=f2e215]:
                  - generic [ref=f2e216]:
                    - paragraph [ref=f2e217]: 显示与数据
                    - link "外观" [ref=f2e218] [cursor=pointer]:
                      - /url: /settings
                    - link "导航" [ref=f2e226] [cursor=pointer]:
                      - /url: /settings/navigation
                    - link "数据展示" [ref=f2e235] [cursor=pointer]:
                      - /url: /settings/data-display
                  - generic [ref=f2e239]:
                    - paragraph [ref=f2e240]: 偏好与反馈
                    - link "操作偏好" [ref=f2e241] [cursor=pointer]:
                      - /url: /settings/actions
                    - link "语言与地区" [ref=f2e249] [cursor=pointer]:
                      - /url: /settings/locale
                    - link "通知" [ref=f2e254] [cursor=pointer]:
                      - /url: /settings/notifications
                  - generic [ref=f2e258]:
                    - paragraph [ref=f2e259]: 辅助与输入
                    - link "可访问性" [ref=f2e260] [cursor=pointer]:
                      - /url: /settings/accessibility
                    - link "快捷键" [ref=f2e268] [cursor=pointer]:
                      - /url: /settings/shortcuts
            - generic [ref=f2e273]:
              - generic [ref=f2e275]:
                - generic [ref=f2e276]:
                  - heading "页面导航" [level=2] [ref=f2e279]
                  - generic [ref=f2e282]:
                    - generic [ref=f2e285] [cursor=pointer]:
                      - switch "跳转后自动滚动到顶部" [checked] [ref=f2e287]
                      - generic [ref=f2e288]: 跳转后自动滚动到顶部
                    - generic [ref=f2e294] [cursor=pointer]:
                      - switch "显示面包屑" [checked] [ref=f2e296]
                      - generic [ref=f2e297]: 显示面包屑
                    - radiogroup "新页面打开方式" [ref=f2e302]:
                      - generic [ref=f2e306]:
                        - generic [ref=f2e308] [cursor=pointer]:
                          - radio "当前页面" [checked] [ref=f2e310]
                          - generic [ref=f2e312]: 当前页面
                        - generic [ref=f2e315] [cursor=pointer]:
                          - radio "浏览器新标签页" [ref=f2e317]
                          - generic [ref=f2e319]: 浏览器新标签页
                        - generic [ref=f2e322] [cursor=pointer]:
                          - radio "顶部页面标签" [ref=f2e324]
                          - generic [ref=f2e326]: 顶部页面标签
                      - generic [ref=f2e328]: 仅作用于声明允许的入口；Ctrl/Cmd 点击、下载与外链保持原生语义。
                - generic [ref=f2e329]:
                  - heading "页面标签" [level=2] [ref=f2e332]
                  - generic [ref=f2e335]:
                    - generic [ref=f2e338] [cursor=pointer]:
                      - switch "顶部页面标签" [ref=f2e340]
                      - generic [ref=f2e341]: 顶部页面标签
                    - generic [ref=f2e347] [cursor=pointer]:
                      - switch "恢复上次打开的标签" [ref=f2e349]
                      - generic [ref=f2e350]: 恢复上次打开的标签
                    - generic [ref=f2e354]:
                      - generic:
                        - generic:
                          - generic:
                            - switch "固定页面标签" [checked] [disabled]
                          - generic:
                            - generic: 固定页面标签
                            - generic: 先启用顶部页面标签，即可选择是否固定。
                    - generic [ref=f2e356]:
                      - generic [ref=f2e357]: 关闭当前标签后跳转
                      - button "最近使用 关闭当前标签后跳转" [ref=f2e358] [cursor=pointer]:
                        - generic [ref=f2e359]: 最近使用
                      - generic [ref=f2e364]: 关闭当前激活标签后前往的目标。
                      - combobox [ref=f2e367]
                - generic [ref=f2e368]:
                  - heading "侧栏与工作记忆" [level=2] [ref=f2e371]
                  - generic [ref=f2e374]:
                    - generic [ref=f2e377] [cursor=pointer]:
                      - switch "记住展开的侧栏菜单" [ref=f2e379]
                      - generic [ref=f2e380]: 记住展开的侧栏菜单
                    - generic [ref=f2e386] [cursor=pointer]:
                      - switch "记录最近访问" [checked] [ref=f2e388]
                      - generic [ref=f2e389]: 记录最近访问
                    - generic [ref=f2e395] [cursor=pointer]:
                      - switch "显示最近访问" [checked] [ref=f2e397]
                      - generic [ref=f2e398]: 显示最近访问
                    - radiogroup "侧边栏状态" [ref=f2e403]:
                      - generic [ref=f2e407]:
                        - generic [ref=f2e409] [cursor=pointer]:
                          - radio "展开" [ref=f2e411]
                          - generic [ref=f2e413]: 展开
                        - generic [ref=f2e416] [cursor=pointer]:
                          - radio "紧凑" [ref=f2e418]
                          - generic [ref=f2e420]: 紧凑
                        - generic [ref=f2e423] [cursor=pointer]:
                          - radio "记住上次使用状态" [checked] [ref=f2e425]
                          - generic [ref=f2e427]: 记住上次使用状态
              - generic [ref=f2e429]:
                - button "恢复默认" [ref=f2e430] [cursor=pointer]
                - button "恢复全部默认" [ref=f2e431] [cursor=pointer]
```

# Test source

```ts
  1  | import type { Page } from '@playwright/test';
  2  | import { expect, test } from '@playwright/test';
  3  | 
  4  | async function resetAll(page: Page) {
  5  |   await page.goto('/settings/navigation');
  6  |   await page.evaluate(() => {
  7  |     window.localStorage.removeItem('community-go.shell');
  8  |     window.localStorage.removeItem('community-go.workspace');
  9  |   });
  10 |   await page.reload();
  11 |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  12 | }
  13 | 
  14 | async function enableAutoRestore(page: Page) {
  15 |   await page.goto('/settings/navigation');
  16 |   await page.getByRole('heading', { name: '导航' }).first().scrollIntoViewIfNeeded();
  17 |   const sw = page.getByRole('switch', { name: '自动恢复未完成工作' });
> 18 |   await sw.focus();
     |            ^ Error: locator.focus: Test timeout of 30000ms exceeded.
  19 |   await page.keyboard.press('Space');
  20 |   await expect(sw).toBeChecked();
  21 |   await page.waitForTimeout(300);
  22 | }
  23 | 
  24 | async function enableAutosave(page: Page) {
  25 |   await page.goto('/settings/actions');
  26 |   await page.getByRole('heading', { name: '操作偏好' }).first().scrollIntoViewIfNeeded();
  27 |   const sw = page.getByRole('switch', { name: '本地草稿自动保存' });
  28 |   await sw.focus();
  29 |   await page.keyboard.press('Space');
  30 |   await expect(sw).toBeChecked();
  31 |   await page.waitForTimeout(300);
  32 | }
  33 | 
  34 | test('自动恢复未完成工作默认关：有草稿时进入首页不重定向', async ({ page }) => {
  35 |   await resetAll(page);
  36 |   await enableAutosave(page);
  37 |   // 输入草稿后回首页。
  38 |   await page.goto('/reference-resources/create');
  39 |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  40 |   await page.getByLabel('名称').fill('未完成的工作草稿');
  41 |   await page.waitForTimeout(400);
  42 |   await page.goto('/');
  43 |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  44 |   await page.waitForTimeout(600);
  45 |   await expect(page).not.toHaveURL(/reference-resources\/create/);
  46 | });
  47 | 
  48 | test('开启 自动恢复未完成工作：有草稿时首页重定向回草稿页', async ({ page }) => {
  49 |   await resetAll(page);
  50 |   await enableAutoRestore(page);
  51 |   await enableAutosave(page);
  52 |   await page.goto('/reference-resources/create');
  53 |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  54 |   await page.getByLabel('名称').fill('未完成的工作草稿');
  55 |   await page.waitForTimeout(400);
  56 |   await page.goto('/');
  57 |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  58 |   await expect(page).toHaveURL(/reference-resources\/create/);
  59 |   await expect(page.getByLabel('名称')).toHaveValue('未完成的工作草稿');
  60 | });
  61 | 
```