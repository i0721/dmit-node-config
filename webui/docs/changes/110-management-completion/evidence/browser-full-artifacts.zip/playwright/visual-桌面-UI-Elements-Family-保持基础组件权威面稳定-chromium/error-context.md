# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: visual.spec.ts >> 桌面 UI Elements Family 保持基础组件权威面稳定
- Location: apps\web\e2e\visual.spec.ts:28:1

# Error details

```
Error: expect(page).toHaveScreenshot(expected) failed

  23168 pixels (ratio 0.02 of all image pixels) are different.

  Snapshot: ui-elements-desktop.png

Call log:
  - Expect "soft toHaveScreenshot(ui-elements-desktop.png)" with timeout 5000ms
    - verifying given screenshot expectation
  - taking page screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - 21044 pixels (ratio 0.02 of all image pixels) are different.
  - waiting 100ms before taking screenshot
  - taking page screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - captured a stable screenshot
  - 23168 pixels (ratio 0.02 of all image pixels) are different.

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - button "Open Next.js Dev Tools" [ref=e7] [cursor=pointer]
  - alert [ref=e11]
  - link "跳到主要内容 / Skip to content" [ref=e12] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e13]:
    - complementary [ref=e14]:
      - generic [ref=e15]:
        - generic [ref=e16]: C
        - generic [ref=e18]:
          - paragraph [ref=e19]: Community Console
          - paragraph [ref=e20]: 管理工作空间
      - navigation "主导航" [ref=e21]:
        - generic [ref=e22]:
          - paragraph [ref=e23]: 工作空间
          - list "工作空间" [ref=e24]:
            - listitem [ref=e25]:
              - link "工作台" [ref=e26] [cursor=pointer]:
                - /url: /
        - generic [ref=e34]:
          - paragraph [ref=e35]: 身份与访问
          - list "身份与访问" [ref=e36]:
            - listitem [ref=e37]:
              - link "用户管理" [ref=e38] [cursor=pointer]:
                - /url: /users
            - listitem [ref=e45]:
              - link "角色管理" [ref=e46] [cursor=pointer]:
                - /url: /roles
        - generic [ref=e53]:
          - paragraph [ref=e54]: 系统管理
          - list "系统管理" [ref=e55]:
            - listitem [ref=e56]:
              - link "审计日志" [ref=e57] [cursor=pointer]:
                - /url: /audit-logs
            - listitem [ref=e63]:
              - link "系统配置" [ref=e64] [cursor=pointer]:
                - /url: /system-settings
        - generic [ref=e70]:
          - paragraph [ref=e71]: 个人
          - list "个人" [ref=e72]:
            - listitem [ref=e73]:
              - link "个人账户" [ref=e74] [cursor=pointer]:
                - /url: /account
            - listitem [ref=e81]:
              - link "通知中心" [ref=e82] [cursor=pointer]:
                - /url: /notifications
            - listitem [ref=e87]:
              - link "个人偏好" [ref=e88] [cursor=pointer]:
                - /url: /settings
        - generic [ref=e94]:
          - paragraph [ref=e95]: 开发中心
          - list "开发中心" [ref=e96]:
            - listitem [ref=e97]:
              - button "展开或收起UI Elements" [expanded] [ref=e98]:
                - generic [ref=e105]: UI Elements
              - list [ref=e108]:
                - listitem [ref=e109]:
                  - link "操作与选择" [ref=e110] [cursor=pointer]:
                    - /url: /ui-elements/actions-selection
                - listitem [ref=e119]:
                  - link "反馈" [ref=e120] [cursor=pointer]:
                    - /url: /ui-elements/feedback
                - listitem [ref=e125]:
                  - link "状态与异步" [ref=e126] [cursor=pointer]:
                    - /url: /ui-elements/status-async
                - listitem [ref=e131]:
                  - link "身份与展示" [ref=e132] [cursor=pointer]:
                    - /url: /ui-elements/identity-display
                - listitem [ref=e139]:
                  - link "导航" [ref=e140] [cursor=pointer]:
                    - /url: /ui-elements/navigation
                - listitem [ref=e150]:
                  - link "数据展示" [ref=e151] [cursor=pointer]:
                    - /url: /ui-elements/data
                - listitem [ref=e156]:
                  - link "表面与卡片" [ref=e157] [cursor=pointer]:
                    - /url: /ui-elements/surfaces
                - listitem [ref=e162]:
                  - link "表单控件" [ref=e163] [cursor=pointer]:
                    - /url: /ui-elements/forms
                - listitem [ref=e169]:
                  - link "浮层与弹出界面" [ref=e170] [cursor=pointer]:
                    - /url: /ui-elements/overlays
            - listitem [ref=e177]:
              - button "展开或收起Page Patterns" [ref=e178]:
                - generic [ref=e185]: Page Patterns
            - listitem [ref=e188]:
              - button "展开或收起Page Archetypes" [ref=e189]:
                - generic [ref=e193]: Page Archetypes
            - listitem [ref=e196]:
              - link "参考资源" [ref=e197] [cursor=pointer]:
                - /url: /reference-resources
            - listitem [ref=e202]:
              - link "Icon 大全" [ref=e203] [cursor=pointer]:
                - /url: /system-tools/icons
            - listitem [ref=e210]:
              - link "基座能力" [ref=e211] [cursor=pointer]:
                - /url: /foundations
            - listitem [ref=e224]:
              - link "Motion" [ref=e225] [cursor=pointer]:
                - /url: /motion
            - listitem [ref=e234]:
              - link "状态体系" [ref=e235] [cursor=pointer]:
                - /url: /states
    - generic [ref=e242]:
      - banner [ref=e244]:
        - button "收起侧栏" [ref=e246] [cursor=pointer]
        - button "按 Ctrl K 搜索" [ref=e248] [cursor=pointer]
        - generic [ref=e249]:
          - generic [ref=e250]:
            - button "切换语言" [ref=e251] [cursor=pointer]
            - button "切换主题" [ref=e252] [cursor=pointer]
          - button "通知" [ref=e253]
          - button "当前用户" [ref=e257] [cursor=pointer]:
            - generic [ref=e259]:
              - generic "Rin" [ref=e262]: RI
              - generic [ref=e263]: Rin
      - main [ref=e267]:
        - generic [ref=e269]:
          - generic [ref=e270]:
            - list "面包屑导航" [ref=e271]:
              - listitem [ref=e272]:
                - link "基座验证" [ref=e273] [cursor=pointer]
                - generic [ref=e274]: /
              - listitem [ref=e275]:
                - link "UI Elements" [ref=e276] [cursor=pointer]
                - generic [ref=e277]: /
              - listitem [ref=e278]:
                - link "操作与选择" [disabled]
            - generic [ref=e280]:
              - paragraph [ref=e281]: UI Elements · Catalog
              - heading "操作与选择" [level=1] [ref=e282]
              - paragraph [ref=e283]: 这是用于验证正常内容节奏的短说明。
          - generic [ref=e284]:
            - generic [ref=e285]:
              - generic [ref=e286]: 展示密度
              - button "舒适 展示密度" [ref=e287] [cursor=pointer]:
                - generic [ref=e288]: 舒适
              - combobox [ref=e295]
            - generic [ref=e297] [cursor=pointer]:
              - switch "扩展文本" [ref=e299]
              - generic [ref=e300]:
                - generic [ref=e301]: 扩展文本
                - generic [ref=e302]: 切换到极长内容以验证传播范围。
            - generic [ref=e306] [cursor=pointer]:
              - switch "English Locale" [ref=e308]
              - generic [ref=e309]:
                - generic [ref=e310]: English Locale
                - generic [ref=e311]: 切换中英文并观察文本扩张与布局。
          - region "UI Elements 分类导航" [ref=e315]:
            - generic [ref=e316]:
              - generic [ref=e317]:
                - paragraph [ref=e318]: 公开契约目录
                - heading "操作与选择" [level=2] [ref=e319]
                - paragraph [ref=e320]: 这是用于验证正常内容节奏的短说明。
              - generic [ref=e321]: 3 / 公开 Element 46 / 46
            - navigation "UI Elements 分类导航" [ref=e323]:
              - link "操作与选择 · 3" [ref=e324] [cursor=pointer]:
                - /url: /ui-elements/actions-selection
              - link "反馈 · 4" [ref=e327] [cursor=pointer]:
                - /url: /ui-elements/feedback
              - link "状态与异步 · 7" [ref=e330] [cursor=pointer]:
                - /url: /ui-elements/status-async
              - link "身份与展示 · 4" [ref=e333] [cursor=pointer]:
                - /url: /ui-elements/identity-display
              - link "导航 · 7" [ref=e336] [cursor=pointer]:
                - /url: /ui-elements/navigation
              - link "数据展示 · 1" [ref=e339] [cursor=pointer]:
                - /url: /ui-elements/data
              - link "表面与卡片 · 2" [ref=e342] [cursor=pointer]:
                - /url: /ui-elements/surfaces
              - link "表单控件 · 10" [ref=e345] [cursor=pointer]:
                - /url: /ui-elements/forms
              - link "浮层与弹出界面 · 8" [ref=e348] [cursor=pointer]:
                - /url: /ui-elements/overlays
          - navigation "本页区段" [ref=e351]:
            - link "Action Variants" [ref=e352] [cursor=pointer]:
              - /url: /ui-elements/actions-selection#actions
            - link "Action" [ref=e353] [cursor=pointer]:
              - /url: /ui-elements/actions-selection#element-action
            - link "IconAction" [ref=e354] [cursor=pointer]:
              - /url: /ui-elements/actions-selection#element-iconaction
            - link "ToggleGroup" [ref=e355] [cursor=pointer]:
              - /url: /ui-elements/actions-selection#element-togglegroup
          - generic [ref=e357]:
            - generic [ref=e359]:
              - heading "Action Variants" [level=2] [ref=e360]
              - paragraph [ref=e361]: 这是用于验证正常内容节奏的短说明。
            - generic [ref=e363]:
              - generic [ref=e364]:
                - generic [ref=e365]:
                  - generic [ref=e366]:
                    - heading "Action" [level=3] [ref=e367]
                    - generic "Action 状态" [ref=e368]:
                      - generic [ref=e369]: 主要
                      - generic [ref=e371]: 次要
                      - generic [ref=e373]: 低强调
                      - generic [ref=e375]: 危险
                      - generic [ref=e377]: sm / md / lg
                      - generic [ref=e379]: 图标
                      - generic [ref=e381]: 提交中
                      - generic [ref=e383]: 禁用
                  - paragraph [ref=e385]: 命令动作以稳定 intent、size、icon 与 pending 语义表达，不承担导航。
                - generic [ref=e387]:
                  - button "主要操作" [ref=e388] [cursor=pointer]
                  - button "次要操作" [ref=e391] [cursor=pointer]
                  - button "低强调操作" [ref=e394] [cursor=pointer]
                  - button "危险操作" [ref=e396] [cursor=pointer]
                  - button "小尺寸" [ref=e398] [cursor=pointer]
                  - button "大尺寸" [ref=e400] [cursor=pointer]
                  - button "处理中" [disabled]
                  - button "不可用" [disabled]
              - generic [ref=e402]:
                - generic [ref=e403]:
                  - generic [ref=e404]:
                    - heading "IconAction" [level=3] [ref=e405]
                    - generic "IconAction 状态" [ref=e406]:
                      - generic [ref=e407]: sm / md
                      - generic [ref=e409]: 活动
                      - generic [ref=e411]: 危险
                      - generic [ref=e413]: 提交中
                      - generic [ref=e415]: 禁用
                      - generic [ref=e417]: 无障碍名称
                  - paragraph [ref=e419]: 空间受限的图标命令必须保留可访问名称、活动态和危险语义。
                - generic [ref=e421]:
                  - button "搜索" [ref=e422] [cursor=pointer]
                  - button "刷新" [ref=e423] [cursor=pointer]
                  - button "删除" [ref=e424] [cursor=pointer]
                  - button "更多操作" [ref=e425] [cursor=pointer]
                  - button "刷新处理中" [disabled]
                  - button "更多操作不可用" [disabled]
              - generic [ref=e426]:
                - generic [ref=e427]:
                  - generic [ref=e428]:
                    - heading "ToggleGroup" [level=3] [ref=e429]
                    - generic "ToggleGroup 状态" [ref=e430]:
                      - generic [ref=e431]: 单选
                      - generic [ref=e433]: 多选
                      - generic [ref=e435]: 选中
                      - generic [ref=e437]: 禁用项目
                      - generic [ref=e439]: sm / md
                      - generic [ref=e441]: 图标
                  - paragraph [ref=e443]: 即时视图偏好支持单选或多选，不与表单 RadioGroup 混用。
                - generic [ref=e445]:
                  - generic [ref=e446]:
                    - generic [ref=e447]: 视图模式
                    - radiogroup "视图模式" [ref=e448]:
                      - radio "网格" [checked] [ref=e449] [cursor=pointer]
                      - radio "列表" [ref=e452] [cursor=pointer]
                      - radio "不可用" [disabled]
                  - generic [ref=e455]:
                    - generic [ref=e456]: 可见列
                    - toolbar "可见列" [ref=e457]:
                      - button "职责层" [pressed] [ref=e458] [cursor=pointer]
                      - button "状态" [pressed] [ref=e460] [cursor=pointer]
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { waitForVisualReadiness } from './visual-readiness';
  3   | 
  4   | async function expectHydrated(page: Page) {
  5   |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  6   |   await waitForVisualReadiness(page);
  7   | }
  8   | 
  9   | async function expectReferenceReady(page: Page) {
  10  |   await expectHydrated(page);
  11  |   await expect(page.getByRole('heading', { level: 1 })).toHaveText('高密度数据工作台');
  12  |   // 默认每页 20 → 首页 20 数据行 + 1 表头。
  13  |   await expect(page.getByRole('grid').getByRole('row')).toHaveCount(21);
  14  | }
  15  | 
  16  | test('桌面与超宽屏 Reference 布局保持稳定', async ({ page }) => {
  17  |   await page.setViewportSize({ width: 1440, height: 900 });
  18  |   await page.goto('/page-archetypes/resource-list');
  19  |   await expectReferenceReady(page);
  20  |   await expect.soft(page).toHaveScreenshot('reference-desktop.png', { fullPage: true });
  21  | 
  22  |   await page.setViewportSize({ width: 1920, height: 1080 });
  23  |   await page.reload();
  24  |   await expectReferenceReady(page);
  25  |   await expect.soft(page).toHaveScreenshot('reference-ultrawide.png', { fullPage: true });
  26  | });
  27  | 
  28  | test('桌面 UI Elements Family 保持基础组件权威面稳定', async ({ page }) => {
  29  |   const consoleErrors: string[] = [];
  30  |   page.on('console', (message) => {
  31  |     if (message.type() === 'error') consoleErrors.push(message.text());
  32  |   });
  33  |   await page.setViewportSize({ width: 1440, height: 1000 });
  34  |   await page.goto('/ui-elements/actions-selection');
  35  |   await expectHydrated(page);
  36  |   await expect(page.getByRole('heading', { level: 1, name: '操作与选择' })).toBeVisible();
  37  |   await expect(page.getByText('公开 Element 46 / 46')).toBeVisible();
  38  |   await waitForVisualReadiness(page);
> 39  |   await expect.soft(page).toHaveScreenshot('ui-elements-desktop.png', { fullPage: true });
      |                           ^ Error: expect(page).toHaveScreenshot(expected) failed
  40  |   expect(consoleErrors).toEqual([]);
  41  | });
  42  | 
  43  | test('九个 UI Element Family 页面均有独立视觉基线', async ({ page }) => {
  44  |   // Nine independent renders and snapshot comparisons retain their per-assertion limit.
  45  |   test.setTimeout(120_000);
  46  |   await page.setViewportSize({ width: 1440, height: 1000 });
  47  | 
  48  |   const families = [
  49  |     'actions-selection',
  50  |     'feedback',
  51  |     'status-async',
  52  |     'identity-display',
  53  |     'navigation',
  54  |     'data',
  55  |     'surfaces',
  56  |     'forms',
  57  |     'overlays',
  58  |   ] as const;
  59  | 
  60  |   for (const family of families) {
  61  |     await page.goto(`/ui-elements/${family}`);
  62  |     await expectHydrated(page);
  63  |     await expect(page.getByText('公开 Element 46 / 46')).toBeVisible();
  64  |     const sectionId = family === 'actions-selection' ? 'actions' : family;
  65  |     await expect
  66  |       .soft(page.locator(`#${sectionId}`))
  67  |       .toHaveScreenshot(`ui-elements-family-${family}.png`);
  68  |   }
  69  | });
  70  | 
  71  | test('移动窗口、Dark Mode 与英文扩张保持无溢出', async ({ page }) => {
  72  |   await page.setViewportSize({ width: 390, height: 844 });
  73  |   await page.goto('/ui-elements/forms');
  74  |   await expectHydrated(page);
  75  |   await page.getByRole('button', { name: '当前用户', exact: true }).click();
  76  |   await page.getByRole('menuitem', { name: /^主题 / }).click();
  77  |   await page.getByRole('menuitemradio', { name: '深色', exact: true }).click();
  78  |   await page.getByRole('button', { name: '当前用户', exact: true }).click();
  79  |   await page.getByRole('menuitem', { name: '语言 简体中文', exact: true }).click();
  80  |   await page.getByRole('menuitemradio', { name: 'English', exact: true }).click();
  81  |   await expect(page.locator('html')).toHaveAttribute('lang', 'en');
  82  |   const overflow = await page.evaluate(
  83  |     () => document.documentElement.scrollWidth - window.innerWidth,
  84  |   );
  85  |   expect(overflow).toBeLessThanOrEqual(0);
  86  |   await expect.soft(page).toHaveScreenshot('ui-elements-mobile-dark-en.png', { fullPage: true });
  87  | });
  88  | 
  89  | test('移动侧栏打开状态纳入视觉回归', async ({ page }) => {
  90  |   await page.setViewportSize({ width: 390, height: 844 });
  91  |   await page.goto('/page-archetypes/resource-list');
  92  |   await expectHydrated(page);
  93  |   await page.getByRole('button', { name: '打开导航' }).click();
  94  |   await expect(page.getByRole('navigation', { name: '主导航' })).toBeVisible();
  95  |   await expect.soft(page).toHaveScreenshot('mobile-navigation-open.png');
  96  | });
  97  | 
  98  | test('状态体系页面保持 Loading 与异常状态视觉基线', async ({ page }) => {
  99  |   await page.setViewportSize({ width: 1440, height: 900 });
  100 |   await page.goto('/states');
  101 |   await expectHydrated(page);
  102 |   await expect(page.getByRole('heading', { name: '加载未完成' })).toBeVisible();
  103 |   await expect(page.getByRole('region', { name: '正在同步界面能力' })).toHaveAttribute(
  104 |     'aria-busy',
  105 |     'true',
  106 |   );
  107 |   await expect.soft(page).toHaveScreenshot('states-desktop.png', { fullPage: true });
  108 | });
  109 | 
  110 | test('Overview、Reference Form 与 Settings 真实页面进入视觉矩阵', async ({ page }) => {
  111 |   await page.setViewportSize({ width: 1440, height: 900 });
  112 | 
  113 |   await page.goto('/');
  114 |   await expectHydrated(page);
  115 |   await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  116 |   await expect.soft(page).toHaveScreenshot('overview-desktop.png', { fullPage: true });
  117 | 
  118 |   await page.goto('/page-archetypes/create-edit');
  119 |   await expectHydrated(page);
  120 |   await expect(page.getByRole('heading', { name: '复杂设置与审批表单' })).toBeVisible();
  121 |   await expect.soft(page).toHaveScreenshot('reference-form-desktop.png', { fullPage: true });
  122 | 
  123 |   await page.goto('/settings');
  124 |   await expectHydrated(page);
  125 |   // 根 /settings 即默认外观分类页（无索引主页）。
  126 |   await expect(page.getByRole('heading', { level: 1, name: '外观' })).toBeVisible();
  127 |   await expect.soft(page).toHaveScreenshot('settings-desktop.png', { fullPage: true });
  128 | });
  129 | 
  130 | test('Toast、Destructive Confirm 与 Compact Density 开启态进入视觉矩阵', async ({ page }) => {
  131 |   await page.setViewportSize({ width: 1440, height: 900 });
  132 | 
  133 |   await page.goto('/ui-elements/feedback?overlay=toast&density=compact');
  134 |   await expectHydrated(page);
  135 |   await expect(page.getByText('项目反馈已入队')).toBeVisible();
  136 |   await expect.soft(page).toHaveScreenshot('ui-elements-toast-compact.png');
  137 | 
  138 |   await page.goto('/ui-elements/overlays?overlay=confirm');
  139 |   await expectHydrated(page);
```