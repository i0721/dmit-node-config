# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: settings-product-review.spec.ts >> All settings fields remain readable and accessible: navigation
- Location: apps\web\e2e\settings-product-review.spec.ts:66:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 12
Received: 11
```

# Test source

```ts
  29  |                 fontScale: expanded ? 'large' : 'standard',
  30  |                 contrast: 'high',
  31  |                 accent,
  32  |               },
  33  |               localeRegion: { ...preferences.localeRegion, language: expanded ? 'en' : 'zh-CN' },
  34  |             },
  35  |           },
  36  |         }),
  37  |       );
  38  |     },
  39  |     { preferences: defaultPreferences, version: PREFERENCES_VERSION, expanded, accent },
  40  |   );
  41  | }
  42  | 
  43  | async function expectAccessible(page: Page) {
  44  |   const result = await new AxeBuilder({ page })
  45  |     .withTags(['wcag2a', 'wcag2aa', 'wcag21aa'])
  46  |     .analyze();
  47  |   expect(result.violations).toEqual([]);
  48  |   expect(
  49  |     await page.evaluate(
  50  |       () => document.documentElement.scrollWidth <= document.documentElement.clientWidth,
  51  |     ),
  52  |   ).toBe(true);
  53  | }
  54  | 
  55  | // Cover every category under a normal desktop layout and the combined narrow/dark/English/large case.
  56  | for (const category of [
  57  |   '',
  58  |   'navigation',
  59  |   'data-display',
  60  |   'actions',
  61  |   'locale',
  62  |   'notifications',
  63  |   'accessibility',
  64  |   'shortcuts',
  65  | ]) {
  66  |   test(`All settings fields remain readable and accessible: ${category || 'appearance'}`, async ({
  67  |     browser,
  68  |   }) => {
  69  |     for (const expanded of [false, true]) {
  70  |       const context = await browser.newContext({
  71  |         baseURL: 'http://127.0.0.1:4173',
  72  |         viewport: { width: expanded ? 320 : 1440, height: 900 },
  73  |         hasTouch: expanded,
  74  |       });
  75  |       try {
  76  |         const page = await context.newPage();
  77  |         await seedAppearance(page, expanded);
  78  |         await page.goto(`/settings${category ? `/${category}` : ''}`);
  79  |         await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  80  |         await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  81  |         await expect(page.locator('html')).toHaveAttribute('data-contrast', 'high');
  82  |         await expectAccessible(page);
  83  |         if (expanded) {
  84  |           const navigation = page.getByRole('button', {
  85  |             name: 'Categories and search',
  86  |             exact: true,
  87  |           });
  88  |           await expect(navigation).toBeVisible();
  89  |           expect(
  90  |             await navigation.evaluate((element) => element.scrollWidth <= element.clientWidth),
  91  |           ).toBe(true);
  92  |         }
  93  |         if (category === '') {
  94  |           const theme = page.getByRole('radiogroup', {
  95  |             name: expanded ? 'Theme mode' : '主题模式',
  96  |             exact: true,
  97  |           });
  98  |           const labels = await theme
  99  |             .locator('.ui-choice-content .font-semibold')
  100 |             .evaluateAll((elements) =>
  101 |               elements.map(
  102 |                 (element) =>
  103 |                   element.getBoundingClientRect().height /
  104 |                   Number.parseFloat(getComputedStyle(element).lineHeight),
  105 |               ),
  106 |             );
  107 |           expect(labels).toHaveLength(3);
  108 |           for (const lines of labels) expect(lines).toBeLessThanOrEqual(2);
  109 |         }
  110 |         const fields = await page
  111 |           .getByRole('main')
  112 |           .locator('[id^="settings-"]')
  113 |           .evaluateAll((elements) =>
  114 |             elements.map((element) => ({
  115 |               id: element.id,
  116 |               width: element.getBoundingClientRect().width,
  117 |             })),
  118 |           );
  119 |         const fieldCounts: Readonly<Record<string, number>> = {
  120 |           '': 7,
  121 |           navigation: 12,
  122 |           'data-display': 10,
  123 |           actions: 18,
  124 |           locale: 7,
  125 |           notifications: 7,
  126 |           accessibility: 4,
  127 |           shortcuts: 2,
  128 |         };
> 129 |         expect(fields.length).toBe(fieldCounts[category]);
      |                               ^ Error: expect(received).toBe(expected) // Object.is equality
  130 |         expect(new Set(fields.map((field) => field.id)).size).toBe(fields.length);
  131 |         for (const field of fields) expect(field.width, field.id).toBeGreaterThanOrEqual(44);
  132 |         await saveEvidenceScreenshot(page, {
  133 |           path: `${evidence}/${category || 'appearance'}-${expanded ? '320-dark-en-large' : '1440-light'}.png`,
  134 |           fullPage: true,
  135 |           animations: 'disabled',
  136 |         });
  137 |       } finally {
  138 |         await context.close();
  139 |       }
  140 |     }
  141 |   });
  142 | }
  143 | 
  144 | for (const family of ['forms', 'actions-selection', 'data', 'overlays']) {
  145 |   for (const expanded of [false, true]) {
  146 |     test(`Shared controls preserve high contrast: ${family}, ${expanded ? 'dark narrow English' : 'light desktop'}`, async ({
  147 |       browser,
  148 |     }) => {
  149 |       const context = await browser.newContext({
  150 |         baseURL: 'http://127.0.0.1:4173',
  151 |         viewport: { width: expanded ? 390 : 1440, height: 900 },
  152 |       });
  153 |       try {
  154 |         const page = await context.newPage();
  155 |         await seedAppearance(page, expanded);
  156 |         await page.goto(`/ui-elements/${family}`);
  157 |         await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  158 |         if (family === 'overlays') {
  159 |           const trigger = page.getByRole('button', { name: 'Dialog', exact: true });
  160 |           await trigger.press('Enter');
  161 |           const dialog = page.getByRole('dialog', {
  162 |             name: expanded ? 'Edit display name' : '编辑显示名称',
  163 |             exact: true,
  164 |           });
  165 |           await expect(dialog).toBeVisible();
  166 |           await page.keyboard.press('Tab');
  167 |           await expectAccessible(page);
  168 |           await saveEvidenceScreenshot(page, {
  169 |             path: `${evidence}/high-contrast-dialog-${expanded ? 'dark' : 'light'}.png`,
  170 |             animations: 'disabled',
  171 |           });
  172 |           await page.keyboard.press('Escape');
  173 |           await expect(dialog).not.toBeVisible();
  174 |           await expect(trigger).toBeFocused();
  175 |         } else {
  176 |           await expectAccessible(page);
  177 |         }
  178 |       } finally {
  179 |         await context.close();
  180 |       }
  181 |     });
  182 |   }
  183 | }
  184 | 
  185 | test('Collapsed desktop sidebar releases its grid column on mobile and restores it on desktop', async ({
  186 |   page,
  187 | }) => {
  188 |   await page.setViewportSize({ width: 1440, height: 900 });
  189 |   await page.goto('/settings/navigation');
  190 |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  191 |   const compact = page
  192 |     .getByRole('radiogroup', { name: '侧边栏状态', exact: true })
  193 |     .getByRole('radio', { name: '紧凑', exact: true });
  194 |   await compact.press('Space');
  195 |   await expect(compact).toBeChecked();
  196 |   const shell = page.locator('.surface-shell-grid');
  197 |   await expect(shell).toHaveAttribute('data-sidebar', 'collapsed');
  198 |   for (const width of [1023, 768, 390, 320]) {
  199 |     await page.setViewportSize({ width, height: 900 });
  200 |     for (const path of ['/settings', '/reference-resources']) {
  201 |       await page.goto(path);
  202 |       await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  203 |       const available = await page.evaluate(() => document.documentElement.clientWidth);
  204 |       await expect
  205 |         .poll(() =>
  206 |           page.getByRole('main').evaluate((element) => element.getBoundingClientRect().width),
  207 |         )
  208 |         .toBe(available);
  209 |       await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  210 |       await expect(shell).toHaveAttribute('data-sidebar', 'collapsed');
  211 |     }
  212 |   }
  213 |   await saveEvidenceScreenshot(page, {
  214 |     path: `${evidence}/collapsed-sidebar-320.png`,
  215 |     animations: 'disabled',
  216 |   });
  217 |   await page.setViewportSize({ width: 1440, height: 900 });
  218 |   await expect
  219 |     .poll(() =>
  220 |       shell.evaluate((element) => getComputedStyle(element).gridTemplateColumns.split(' ').length),
  221 |     )
  222 |     .toBe(2);
  223 |   await expect(page.getByRole('button', { name: '展开侧栏', exact: true })).toBeVisible();
  224 | });
  225 | 
  226 | for (const accent of ['blue', 'green', 'orange'] as const) {
  227 |   for (const expanded of [false, true]) {
  228 |     test(`Dialog confirmation uses the accent foreground: ${accent}, ${expanded ? 'dark' : 'light'}`, async ({
  229 |       page,
```