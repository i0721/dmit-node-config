# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: new-page-open-mode.spec.ts >> 新页面打开方式=浏览器新标签页：声明允许入口在新标签打开
- Location: apps\web\e2e\new-page-open-mode.spec.ts:19:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.waitForEvent: Test timeout of 30000ms exceeded.
=========================== logs ===========================
waiting for event "popup"
============================================================
```

# Page snapshot

```yaml
- generic [active] [ref=f3e1]:
  - button "Open Next.js Dev Tools" [ref=f3e7] [cursor=pointer]
  - alert [ref=f3e11]
  - link "跳到主要内容 / Skip to content" [ref=f3e12] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f3e13]:
    - complementary [ref=f3e14]:
      - generic [ref=f3e15]:
        - generic [ref=f3e16]: C
        - generic [ref=f3e18]:
          - paragraph [ref=f3e19]: Community Console
          - paragraph [ref=f3e20]: 管理工作空间
      - navigation "主导航" [ref=f3e21]:
        - generic [ref=f3e22]:
          - paragraph [ref=f3e23]: 工作空间
          - list "工作空间" [ref=f3e24]:
            - listitem [ref=f3e25]:
              - link "工作台" [ref=f3e26] [cursor=pointer]:
                - /url: /
        - generic [ref=f3e34]:
          - paragraph [ref=f3e35]: 身份与访问
          - list "身份与访问" [ref=f3e36]:
            - listitem [ref=f3e37]:
              - link "用户管理" [ref=f3e38] [cursor=pointer]:
                - /url: /users
            - listitem [ref=f3e45]:
              - link "角色管理" [ref=f3e46] [cursor=pointer]:
                - /url: /roles
        - generic [ref=f3e53]:
          - paragraph [ref=f3e54]: 系统管理
          - list "系统管理" [ref=f3e55]:
            - listitem [ref=f3e56]:
              - link "审计日志" [ref=f3e57] [cursor=pointer]:
                - /url: /audit-logs
            - listitem [ref=f3e63]:
              - link "系统配置" [ref=f3e64] [cursor=pointer]:
                - /url: /system-settings
        - generic [ref=f3e70]:
          - paragraph [ref=f3e71]: 个人
          - list "个人" [ref=f3e72]:
            - listitem [ref=f3e73]:
              - link "个人账户" [ref=f3e74] [cursor=pointer]:
                - /url: /account
            - listitem [ref=f3e81]:
              - link "通知中心" [ref=f3e82] [cursor=pointer]:
                - /url: /notifications
            - listitem [ref=f3e87]:
              - link "个人偏好" [ref=f3e88] [cursor=pointer]:
                - /url: /settings
        - generic [ref=f3e94]:
          - paragraph [ref=f3e95]: 开发中心
          - list "开发中心" [ref=f3e96]:
            - listitem [ref=f3e97]:
              - button "展开或收起UI Elements" [ref=f3e98]:
                - generic [ref=f3e105]: UI Elements
            - listitem [ref=f3e108]:
              - button "展开或收起Page Patterns" [ref=f3e109]:
                - generic [ref=f3e116]: Page Patterns
            - listitem [ref=f3e119]:
              - button "展开或收起Page Archetypes" [ref=f3e120]:
                - generic [ref=f3e124]: Page Archetypes
            - listitem [ref=f3e127]:
              - link "参考资源" [ref=f3e128] [cursor=pointer]:
                - /url: /reference-resources
            - listitem [ref=f3e133]:
              - link "Icon 大全" [ref=f3e134] [cursor=pointer]:
                - /url: /system-tools/icons
            - listitem [ref=f3e141]:
              - link "基座能力" [ref=f3e142] [cursor=pointer]:
                - /url: /foundations
            - listitem [ref=f3e155]:
              - link "Motion" [ref=f3e156] [cursor=pointer]:
                - /url: /motion
            - listitem [ref=f3e165]:
              - link "状态体系" [ref=f3e166] [cursor=pointer]:
                - /url: /states
    - generic [ref=f3e173]:
      - banner [ref=f3e175]:
        - button "收起侧栏" [ref=f3e177] [cursor=pointer]
        - button "按 Ctrl K 搜索" [ref=f3e179] [cursor=pointer]
        - generic [ref=f3e180]:
          - generic [ref=f3e181]:
            - button "切换语言" [ref=f3e182] [cursor=pointer]
            - button "切换主题" [ref=f3e183] [cursor=pointer]
          - button "通知" [ref=f3e184]
          - button "当前用户" [ref=f3e188] [cursor=pointer]:
            - generic [ref=f3e190]:
              - generic "Rin" [ref=f3e193]: RI
              - generic [ref=f3e194]: Rin
      - main [ref=f3e198]:
        - generic [ref=f3e200]:
          - generic [ref=f3e203]:
            - heading "工作台" [level=1] [ref=f3e204]
            - paragraph
          - generic [ref=f3e206]:
            - heading "最近访问" [level=2] [ref=f3e209]
            - list [ref=f3e211]:
              - listitem [ref=f3e212]:
                - link "导航" [ref=f3e213] [cursor=pointer]:
                  - /url: /settings/navigation
                - time [ref=f3e216]: 2026/10/13 · 15:16
```

# Test source

```ts
  1  | import type { Page } from '@playwright/test';
  2  | import { expect, test } from '@playwright/test';
  3  | 
  4  | async function resetPreferences(page: Page) {
  5  |   await page.goto('/settings/navigation');
  6  |   await page.evaluate(() => window.localStorage.removeItem('community-go.shell'));
  7  |   await page.reload();
  8  |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  9  | }
  10 | 
  11 | test('新页面打开方式默认当前页：点击链接同页导航', async ({ page }) => {
  12 |   await resetPreferences(page);
  13 |   await page.goto('/');
  14 |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
  15 |   await page.getByRole('link', { name: '图标工具' }).click();
  16 |   await expect(page).toHaveURL(/\/system-tools\/icons/);
  17 | });
  18 | 
  19 | test('新页面打开方式=浏览器新标签页：声明允许入口在新标签打开', async ({ page }) => {
  20 |   await resetPreferences(page);
  21 |   // 设置 → 导航 → 新页面打开方式 = 浏览器新标签页。
  22 |   await page.goto('/settings/navigation');
  23 |   await page.getByRole('heading', { name: '导航' }).first().scrollIntoViewIfNeeded();
  24 |   await page
  25 |     .getByRole('radiogroup', { name: '新页面打开方式' })
  26 |     .getByText('浏览器新标签页', { exact: true })
  27 |     .click();
  28 |   await page.waitForTimeout(300);
  29 | 
  30 |   await page.goto('/');
  31 |   await expect(page.locator('html')).toHaveAttribute('data-hydrated', 'true');
> 32 |   const popupPromise = page.waitForEvent('popup');
     |                             ^ Error: page.waitForEvent: Test timeout of 30000ms exceeded.
  33 |   await page.getByRole('link', { name: '图标工具' }).click();
  34 |   const popup = await popupPromise;
  35 |   await popup.waitForLoadState();
  36 |   expect(popup.url()).toContain('/system-tools/icons');
  37 |   // 当前页仍在首页（未被导航离开）。
  38 |   await expect(page).toHaveURL(/\/$/);
  39 | });
  40 | 
```